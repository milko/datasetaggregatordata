class TestClass {
	const a_constant = "constant";
	
	construct() {
	}
	
	test() {
		return "This is a test";
	}
}

module.exports = TestClass;

# SmartDataServices

SMART surveys aggregator data services.

# License

Copyright (c) 2018 Milko Skofic

License: Apache 2
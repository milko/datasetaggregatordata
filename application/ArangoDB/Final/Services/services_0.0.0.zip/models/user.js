'use strict';

//
// Frameworks.
//
const _ = require('lodash');							// WTF?
const Joi = require('joi');								// Validation framework.

//
// Application.
//
const K = require( '../utils/Constant' );				// Application constants.

//
// Build validation chain.
//
const schema = {};
schema[ K.user.field.code ] = Joi.string().required();
schema[ K.user.field.email ] = Joi.string().email().required();
schema[ K.user.field.name ] = Joi.string().required();
schema[ K.user.field.lang ] = Joi.string().required();
schema[ K.user.field.rank ] = Joi.string().required();
schema[ K.user.field.role ] = Joi.string().required();
schema[ K.user.field.status ] = Joi.string();

module.exports = {
	schema: schema,

	forClient( obj ) {
		// Implement outgoing transformations here
		obj = _.omit( obj, [ '_id', '_key', '_rev', '_oldRev', 'auth' ] );
		return obj;
	},

	fromClient( obj ) {
		// Implement incoming transformations here
		return obj;
	}
};

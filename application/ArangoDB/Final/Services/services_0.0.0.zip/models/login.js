'use strict';

//
// Frameworks.
//
const _ = require('lodash');							// WTF?
const Joi = require('joi');								// Validation framework.

module.exports = {
	schema: {
		username: Joi.string().required(),
		password: Joi.string().required()
	},
	forClient(obj) {
		// Implement outgoing transformations here
		obj = _.omit( obj, [ '_id', '_rev', '_oldRev', 'auth' ] );
		return obj;
	},
	fromClient(obj) {
		// Implement incoming transformations here
		return obj;
	}
};

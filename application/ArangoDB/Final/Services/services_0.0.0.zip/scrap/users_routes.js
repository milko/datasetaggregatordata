

/**
 * Signup user
 *
 * The service will signup a user.
 *
 * The service expects the user data to be provided in the body as follows:
 * 	- name:		The name of the user.
 * 	- username:	The user's code (optional).
 * 	- email:	The user's e-mail address.
 * 	- language:	The user's preferred language code.
 * 	- rank:		The user's rank.
 * 	- role:		The user's role.
 *
 * The service will perform the following assertions:
 * 	- There must be a current user and it must have administration role.
 *
 * The service will return the token.
 *
 * @path		/signin/sysadm/:token
 * @verb		post
 * @request		{Object}	Authentication parameters and administrator user.
 * @response	{Object}	The token.
 */
router.post(

	//
	// Path.
	//
	'/signup',

	//
	// Middleware.
	//
	User.middleware.assert.manage,			// Ensure current user is manager.

	//
	// Handler.
	//
	User.handlers.signup,					// Handler.

	'sysAdmin'								// Name.
)
	.body(
		SchemaUser,
		'User credentials.'
	)
	.response(
		201,
		Joi.object({
			token : Joi.string().required()
		}).required(),
		'The user token.'
	)
	.summary(
		"Signup user"
	)
	.description(dd`
  Signup user and return token.
`);


/**
 * Create system administrator
 *
 * The service will create the system administrator user.
 *
 * The service expects a path parameter that represents the authentication
 * token, this parameter will be named "token".
 *
 * The service expects the administrator's user data to be provided in the
 * body as follows:
 * 	- name:		The name of the user.
 * 	- pass:		The user password.
 * 	- email:	The user's e-mail address.
 * 	- language:	The user's preferred language code.
 *
 * The service will perform the following assertions:
 * 	- The users collection must be empty.
 * 	- The path parameter token must match the object stored in the auth.json
 * 	  file in the data directory.
 *
 * The service will return the newly created administrator.
 *
 * @path		/signin/sysadm/:token
 * @verb		post
 * @request		{Object}	Authentication parameters and administrator user.
 * @response	{Object}	The newly created user.
 */
router.post(

	//
	// Path.
	//
	'/signin/sysadm/:token',

	//
	// Middleware.
	//
	User.middleware.assert.noUsers,			// Ensure users collection is empty.
	User.middleware.assert.token.sysAdm,	// Match token with authorisation file.

	//
	// Handler.
	//
	User.handlers.sysAdmin,					// Handler.

	'sysAdmin'								// Name.
)
	.pathParam(
		'token',
		Joi.string().required(),
		'Path parameter.'
	)
	.body(
		SchemaSysAdmin,
		'User credentials.'
	)
	.response(
		201,
		SchemaUser,
		'The created system administrator.'
	)
	.summary(
		"Create system administrator"
	)
	.description(dd`
  Create system administrator user, if there are no users.
`);

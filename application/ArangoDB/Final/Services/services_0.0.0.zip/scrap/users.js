'use strict';

//
// Frameworks.
//
const fs = require('fs');							// File system utilities.
const db = require('@arangodb').db;					// Database framework.
const crypto = require('@arangodb/crypto');			// Cryptographic functions.
const createAuth = require('@arangodb/foxx/auth');	// Authentication framework.

//
// Application.
//
const K = require( './Constant' );					// Application constants.
const MyError = require( './Error' );				// Error class.
const Application = require( './Application' );		// Application functions.

//
// Globals.
//
const kCollection = db._collection( K.collection.user.name );

/**
 * Users management
 *
 * This object contains functions and helpers used to manage users.
 */
module.exports = {

	//
	// Handlers.
	//
	handlers : {

		/**
		 * Who am I?
		 *
		 * Return the current user record.
		 *
		 * @param theRequest	{Object}	The current request.
		 * @param theResponse	{Object}	The current reqponse.
		 */
		whoami : ( theRequest, theResponse ) =>
		{
			//
			// Handle user.
			//
			if( theRequest.user )
				theResponse.send( theRequest.user );								// ==>

			//
			// Handle no user.
			//
			else
				theResponse.throw(
					404,
					new MyError( 11, 'NoCurrentUser' )
				);																// !@! ==>

		},	// whoami

		/**
		 * Login
		 *
		 * Login user.
		 *
		 * @param theRequest	{Object}	username and password.
		 * @param theResponse	{Object}	The user.
		 */
		login : ( theRequest, theResponse ) =>
		{
			//
			// Get credentials.
			//
			const code = theRequest.body.username;
			const pass = theRequest.body.password;

			//
			// Login.
			//
			try
			{
				//
				// Locate user.
				//
				const key = {};
				key[ K.user.field.code ] = code;
				const user =
					db._collection( K.collection.user.name )
						.firstExample( key );

				//
				// Check credentials.
				//
				const auth = createAuth();
				const valid = auth.verify( user.auth, theRequest.body.password );
				if( ! valid )
					theResponse.throw(
						403,
						"Authentication failed."
					);															// !@! ==>

				//
				// Login user.
				//
				theRequest.session.uid = user._id;
				theRequest.session.data = {};
				theRequest.sessionStorage.save( theRequest.session );

				//
				// Copy user to request.
				//
				delete user._id;
				delete user._key;
				delete user._rev;
				delete user._auth;
				theRequest.user = user;

				theResponse.send( user );											// ==>
			}
			catch( error )
			{
				theResponse.throw( error );										// !@! ==>
			}

		},	// login

		/**
		 * Create system administrator
		 *
		 * This handler will create the system administrator user
		 * and log it in.
		 *
		 * @param theRequest	{Object}	The current request.
		 * @param theResponse	{Object}	The current reqponse.
		 */
		signup : ( theRequest, theResponse ) =>
		{
			//
			// Create user.
			// Assume body is correct.
			//
			const user = theRequest.body;
			const code = ( user.hasOwnProperty( K.user.field.code ) )
				? user[ K.user.field.code ]
				: user[ K.user.field.email ];
			if( ! user.hasOwnProperty( K.user.field.code ) )
				user[ K.user.field.code ] = code;

			//
			// Create credentials.
			//
			const credentials = {
				code : code,
				pass : crypto.genRandomAlphaNumbers( 16 )
			};

			//
			// Create token.
			//
			const token = Application.auth.encode()

			//
			// Create user.
			// Assume body is correct.
			//
			user[ K.user.field.code ] = credentials.code;

			//
			// Create authorisation data.
			//
			const auth = createAuth();
			user.auth = auth.create( data.pass );

			//
			// Save user.
			//
			try
			{
				//
				// Insert user.
				//
				kCollection.insert( user );
			}
			catch( error )
			{
				theResponse.throw(
					500,
					"Unable to save system administrator.",
					error
				);																// !@! ==>
			}

			//
			// return .
			//
			delete user.auth;			// Hide authorisation data.
			theRequest.user = user;		// Set user.

			theResponse.send( user );												// ==>

		},	// signup

		/**
		 * Create system administrator
		 *
		 * This handler will create the system administrator user
		 * and log it in.
		 *
		 * @param theRequest	{Object}	The current request.
		 * @param theResponse	{Object}	The current reqponse.
		 */
		sysAdmin : ( theRequest, theResponse ) =>
		{
			//
			// Create user.
			//
			const user = {};
			user[ K.user.field.code ] = K.user.sysadm;
			user[ K.user.field.name ] = theRequest.body[ K.user.field.name ];
			user[ K.user.field.email ] = theRequest.body[ K.user.field.email ];
			user[ K.user.field.lang ] = theRequest.body[ K.user.field.lang ];
			user[ K.user.field.rank ] = K.user.rank.sys;
			user[ K.user.field.role ] = [
				K.user.role.user,
				K.user.role.batch,
				K.user.role.upload,
				K.user.role.meta,
				K.user.role.clean,
				K.user.role.suggest,
				K.user.role.dict,
				K.user.role.commit,
				K.user.role.query,
				K.user.role.download
			];

			//
			// Create authorisation data.
			//
			const auth = createAuth();
			user.auth = auth.create( theRequest.body[ K.user.param.pass ] );

			//
			// Save user.
			//
			try
			{
				//
				// Insert user.
				//
				const meta = kCollection.insert( user );

				//
				// Update session.
				//
				theRequest.session.uid = meta._id;
				theRequest.session.data = {};
				theRequest.sessionStorage.save( theRequest.session );
			}
			catch( error )
			{
				theResponse.throw(
					500,
					"Unable to save system administrator.",
					error
				);																// !@! ==>
			}

			//
			// Save user in request.
			//
			delete user.auth;			// Hide authorisation data.
			theRequest.user = user;		// Set user.

			theResponse.send( user );												// ==>
		}
	},

	//
	// User middleware.
	//
	middleware : {

		/**
		 * Assertion middleware
		 *
		 * This group of middleware handles assertions.
		 */
		assert : {

			/**
			 * Check init parameters
			 *
			 * This middleware will check if the provided parameters are correct.
			 *
			 * @param theRequest	{function}	The request.
			 * @param theResponse	{function}	The response.
			 * @param theNext		{function}	The next middleware/handler.
			 */
			noUsers : ( theRequest, theResponse, theNext ) =>
			{
				//
				// Ensure there are no users.
				//
				if( kCollection.count() !== 0 )
					theResponse.throw(
						409,
						"The users collection must be empty."
					);															// !@! ==>

				//
				// Call next.
				//
				theNext();

			},	// noUsers

			/**
			 * Check for user creation
			 *
			 * This middleware will check if the current user can create users.
			 *
			 * @param theRequest	{function}	The request.
			 * @param theResponse	{function}	The response.
			 * @param theNext		{function}	The next middleware/handler.
			 */
			manage : ( theRequest, theResponse, theNext ) =>
			{
				//
				// Ensure there is a current user.
				//
				if( ! theRequest.user )
					theResponse.throw(
						403,
						"No current user."
					);															// !@! ==>

				//
				// Ensure user can manage.
				//
				if( ! theRequest.use.role.includes( K.user.role.user ) )
					theResponse.throw(
						403,
						"User not allowed."
					);															// !@! ==>

				//
				// Call next.
				//
				theNext();

			},	// manage

			/**
			 * Token validation
			 *
			 * These functions will validate authentication tokens.
			 */
			token : {

				/**
				 * Check path parameter
				 *
				 * This middleware expects a path parameter with name "key",
				 *
				 *
				 * This function will check if the provided path parameter corresponds
				 * to the authorisation data in the auth.json file in the data directory.
				 *
				 * The function assumes the path parameter is there.
				 *
				 * @param theRequest	{function}	The request.
				 * @param theResponse	{function}	The response.
				 * @param theNext		{function}	The next middleware/handler.
				 */
				sysAdm : ( theRequest, theResponse, theNext ) =>
				{
					//
					// Get authorisation file.
					//
					const file = module.context.basePath + K.environment.auth.path;
					if( fs.isFile( file ) )
					{
						//
						// Load authorisation data.
						//
						let auth_data = null;
						try
						{
							auth_data = JSON.parse( fs.read( file ) );
						}
						catch( error )
						{
							response.throw(
								500,
								"Unable to load authorisation data.",
								error
							);													// !@! ==>
						}

						//
						// Decode token.
						//
						try
						{
							//
							// Decode.
							//
							const decoded =
								Application.auth.decode(
									auth_data.key,
									theRequest.pathParams.token
								);

							//
							// Validate.
							//
							if( (decoded === null)
								|| (! decoded.hasOwnProperty( 'code' ))
								|| (! decoded.hasOwnProperty( 'pass' ))
								|| (decoded.code !== auth_data.code)
								|| (decoded.pass !== auth_data.pass) )
							{
								theResponse.throw(
									403,
									"Authentication failed."
								);												// !@! ==>
							}
						}
						catch( error )
						{
							theResponse.throw(error);
							theResponse.throw(
								400,
								"Unable to authenticate.",
								error
							);													// !@! ==>
						}
					}
					else
					{
						theResponse.throw(
							404,
							"Missing authentication file."
						);														// !@! ==>
					}

					//
					// Call next.
					//
					theNext();

				}	// sysAdm
			}
		}
	}

};

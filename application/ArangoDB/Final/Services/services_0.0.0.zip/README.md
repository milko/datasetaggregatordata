# SmartServices

SMART survey aggregator data framework

# License

Copyright (c) 2018 Milko Skofic

License: Apache 2
'use strict';

//
// Application.
//
const Application = require( '../utils/Application' );

//
// Create/update document collections.
//
Application.init.collections.document()

//
// Create/update edge collections.
//
Application.init.collections.edge()

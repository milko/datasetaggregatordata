'use strict';

//
// Application.
//
const Application = require( '../utils/Application' );

//
// Drop document collections.
//
Application.tear.collections.document();

//
// Drop edge collections.
//
Application.tear.collections.edge();

'use strict';

//
// Frameworks.
//
const db = require('@arangodb').db;

//
// Application.
//
const K = require( './Constant' );
const Log = require( './Log' );


/**
 * MyError
 *
 * This class implements a custom error instance that builds its message
 * from two sources:
 * 	- the error name, that identifies the generic error type, and
 * 	- the error code, that identifies the specific error.
 *
 * For instance, suppose the requested operation is to retrieve a document
 * requested by the caller: the error name would indicate that the document
 * could not be returned, while the error code would indicate that this was
 * not possible due to a specific error.
 *
 * This class features the following properties:
 * 	- name (inherited):		The error name, the falue is the key to the errors
 * 							collection and will be prepended to the error message.
 * 	- message (inherited):	The error message, it is dynamically created by
 * 							prepending the name message to the error message and
 * 							replacing any '@arg' instance with the value of the
 * 							'argument' property.
 * 	- argument:				Optionally contains data related to the error, it
 * 							will replace any '@arg' instance in all messages.
 * 	- language:				The language of the messages.
 *
 * No methods should throw exceptions (obviously...), but if an error occurs,
 * it will be logged. The class expects the loga, errors and messages collections
 * to exist.
 */
class MyError extends Error
{
	/**
	 * constructor
	 *
	 * The constructor expects the following parameters:
	 * 	- theName:		The error name or class, it represents the error base
	 * 					class whose specifics will be completed by the message.
	 * 	- theMessage:	If it is a string, it will represent the error message,
	 * 					if it is a number, the message will be retrieved from
	 * 					the messages collection in the provided language. This
	 * 					message will be appended to the message corresponding
	 * 					to the error name.
	 * 	- theLanguage:	The language in which the error message should be
	 * 					retrieved.
	 *	- theArgument:	A string containing the data related to the error.
	 *
	 * @param theName		{String}	The error name.
	 * @param theMessage	{String}	The error message or code.
	 * @param theLanguage	{String}	The message language.
	 * @param theArgument	{String}	The error data.
	 */
	constructor(
		theName,
		theMessage,
		theLanguage = K.environment.language,
		theArgument = null )
	{
		//
		// Normalise data.
		//
		if( theArgument !== null )
			theArgument = theArgument.toString();
		if( theLanguage === null )
			theLanguage = K.environment.language;

		//
		// Get messages.
		//
		const mess_name = MyError.nameMessage( theName, theLanguage, theArgument );
		const mess_code = MyError.codeMessage( theMessage, theLanguage, theArgument );

		//
		// Parent constructor.
		//
		super( mess_name + mess_code );

		//
		// Save parameters.
		//
		this.name		= theName;
		this.param_mess = theMessage;
		this.param_lang = theLanguage;
		this.param_data = theArgument;

	}	// constructor.

	/**
	 * Get name message
	 *
	 * This method will retrieve the name message in the provided language and
	 * replace the '@arg' occurrences with the eventual 'argument' member string.
	 *
	 * If the name or language are not available, the message will be the name.
	 *
	 * @param theName		{String}	The error name.
	 * @param theLanguage	{String}	The error message language.
	 * @param theData		{String}	The error data.
	 * @returns {String}				The error message.
	 */
	static nameMessage( theName, theLanguage, theData = null )
	{
		//
		// Init message.
		//
		let message = theName;

		//
		// Retrieve message.
		//
		try
		{
			//
			// Get document.
			//
			const doc =
				db._collection( K.collection.error.name )
					.document( theName );

			//
			// Set message.
			//
			if( doc.label.hasOwnProperty( theLanguage ) )
				message = doc.label[ theLanguage ];
		}
		catch( error )
		{
			//
			// Log error.
			//
			const err = {};
			err[ K.log.ename ] = theName;
			err[ K.log.elang ] = theLanguage;
			err[ K.log.edata ] = theData;

			Log.error( err, error );
		}

		//
		// Set error data.
		//
		if( theData !== null )
			message = message.replace( /@arg/g, theData );

		return message;																// ==>

	}	// nameMessage.

	/**
	 * Get code message
	 *
	 * This method will retrieve the code message in the provided language and
	 * replace the '@arg' occurrences with the eventual 'argument' member string.
	 *
	 * If the code or language are not available, the message will be 'N/A'.
	 *
	 * The code argument can either be a number, in which case it will
	 * constitute the messages collection key by prepending an 'e' to the code;
	 * if the parameter ain't a string, it will be considered the message.
	 *
	 * @param theCode		{Number}|{String}	The error code or message.
	 * @param theLanguage	{String}			The error message language.
	 * @param theData		{String}	The error data.
	 * @returns {String}						The error message.
	 */
	static codeMessage( theCode, theLanguage, theData = null )
	{
		//
		// Init message.
		//
		let message = "N/A";

		//
		// Handle numeric message.
		//
		if( isFinite( theCode )
		 && (! isNaN( parseInt( theCode ) )) )
		{
			//
			// Retrieve message.
			//
			try
			{
				//
				// Get document.
				//
				const doc =
					db._collection( K.collection.message.name )
						.document( 'e' + theCode );

				//
				// Check code.
				//
				if( doc.label.hasOwnProperty( theLanguage ) )
					message = doc.label[ theLanguage ];
			}
			catch( error )
			{
				//
				// Log error.
				//
				const err = {};
				err[ K.log.emess ] = theCode;
				err[ K.log.elang ] = theLanguage;
				err[ K.log.edata ] = theData;

				Log.error( err, error );
			}
		}

		//
		// Handle string message.
		//
		else
			message = theCode;

		//
		// Handle error data.
		//
		if( theData !== null )
			message = message.replace( /@arg/g, theData );

		return message;																// ==>

	}	// codeMessage.
}

module.exports = MyError;

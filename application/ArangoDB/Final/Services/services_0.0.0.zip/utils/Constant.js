'use strict';

/**
 * Constants
 *
 * This module exports all required constants:
 *
 * 	- collection:	Collection names, indexes and collection objects.
 * 	- setting:		Settings constants.
 * 	- log:			Logs constants.
 * 	- user:			Users constants.
 * 	- environment:	Environment constants.
 */
module.exports = Object.freeze({

	//
	// Collections.
	//
	//	- name:		Collection name.
	//	- index:	Collection indexes.
	//
	collection : {
		setting	: {
			name : 'settings',
			index: []
		},
		session	: {
			name : 'sessions',
			index: []
		},
		log	: {
			name : 'logs',
			index: []
		},
		error	: {
			name : 'errors',
			index: []
		},
		message	: {
			name : 'messages',
			index: []
		},

		user	: {
			name : 'users',
			index	: [
				{
					fields:	[ 'username' ],
					type:	'hash',
					unique:	true,
					sparse:	false
				},
				{
					fields:	[ 'email' ],
					type:	'hash',
					unique:	true,
					sparse:	false
				}
			]
		},
		group	: {
			name : 'groups',
			index: []
		},
		hierarchy	: {
			name : 'hierarchies',
			index: []
		},

		term	: {
			name : 'terms',
			index: [
				{
					fields:	[ 'nid' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'lid' ],
					type:	'hash',
					unique:	false,
					sparse:	false
				},
				{
					fields:	[ 'gid' ],
					type:	'skiplist',
					unique:	true,
					sparse:	false
				},
				{
					fields:	[ 'var' ],
					type:	'skiplist',
					unique:	true,
					sparse:	true
				},
				{
					fields:	[ 'syn[*]' ],
					type:	'skiplist',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'keyword[*]' ],
					type:	'skiplist',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'instances[*]' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				}
			]
		},
		descriptor	: {
			name : 'descriptors',
			index: [
				{
					fields:	[ 'nid' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'gid' ],
					type:	'skiplist',
					unique:	true,
					sparse:	false
				},
				{
					fields:	[ 'var' ],
					type:	'skiplist',
					unique:	true,
					sparse:	false
				},
				{
					fields:	[ 'kind' ],
					type:	'hash',
					unique:	false,
					sparse:	false
				},
				{
					fields:	[ 'type' ],
					type:	'hash',
					unique:	false,
					sparse:	false
				},
				{
					fields:	[ 'format' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'unit' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'syn[*]' ],
					type:	'skiplist',
					unique:	false,
					sparse:	false
				},
				{
					fields:	[ 'keyword[*]' ],
					type:	'skiplist',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'terms[*]' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				},
				{
					fields:	[ 'fields[*]' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				}
			]
		},
		schema	: {
			name : 'schemas',
			index: [
				{
					fields:	[ '_from', '_to', 'predicate' ],
					type:	'hash',
					unique:	true,
					sparse:	false
				},
				{
					fields:	[ 'branches[*]' ],
					type:	'hash',
					unique:	false,
					sparse:	true
				}
			]
		},

		study	: {
			name : 'studies',
			index: []
		},
		annex	: {
			name : 'annexes',
			index: []
		},
		smart	: {
			name : 'smart',
			index: []
		},
		link	: {
			name : 'links',
			index: []
		},

		toponym	: {
			name : 'toponyms',
			index: []
		},
		shape	: {
			name : 'shapes',
			index: []
		},
		edge	: {
			name : 'edges',
			index: []
		}
	},

	//
	// Settings.
	//
	setting : {
		status : {
			key				: 'status',			// Status key.
			app : {								// Application:
				key			: 'application',	// key.
				state : {						// Status:
					ok		: 'OK',				// application is usable,
					err		: 'ERROR',			// application is in error,
					busy	: 'BUSY',			// application is busy,
					ddict	: 'ddict'			// missing data dictionary data.
				}
			}
		}
	},

	//
	// Logs.
	//
	log : {
		start			: 'start',			// Creation time stamp (request.stamp.start).
		end				: 'end',			// Termination time stamp (request.stamp.end).
		status			: 'status',			// Status code (response.statusCode).
		session			: 'session',		// Session reference (_key).
		user			: 'user',			// User reference (request.session.uid).
		rank			: 'rank',			// User rank.
		role			: 'role',			// User roles.
		path			: 'url',			// Service path (request.path).
		ip				: 'ip',				// Caller IP address (request.remoteAddress).
		port			: 'port',			// Caller port (request.port).

		ename			: 'e_name',			// Error name.
		emess			: 'e_mess',			// Error message.
		elang			: 'e_lang',			// Error language.
		edata			: 'e_data',			// Error data.
		eexch			: 'e_exch'			// Error exception message.
	},

	//
	// Users.
	//
	user : {
		sysadm			: 'admin',			// System administrator's username.
		field : {
			name		: 'name',			// User name field name.
			code		: 'username',		// User code field name.
			email		: 'email',			// User e-mail addrress field name.
			lang		: 'language',		// User preferred language field name.
			rank		: 'rank',			// User rank field name.
			role		: 'role',			// User roles field name.
			status		: 'status',			// User status field name.
			auth		: 'auth'			// User authentication data.
		},
		param : {
			user		: 'user',			// User document parameter.
			code		: 'username',		// Username parameter.
			pass		: 'password'		// Password parameter.
		},
		rank : {
			sys			: ':rank:system',	// System administrator rank.
			def			: ':rank:default',	// Defaults manager rank.
			std			: ':rank:standard',	// Standards managet rank.
			usr			: ':rank:user',		// Users manager rank.
			guest		: ':rank:guest'		// Guest rank.
		},
		role : {
			user		: ':role:user',		// Can create users.
			batch		: ':role:batch',	// Can launch batch jobs.
			upload		: ':role:upload',	// Can upload study material.
			meta		: ':role:meta',		// Can manage metadata.
			clean		: ':role:clean',	// Can harmonise and clean datasets.
			suggest		: ':role:suggest',	// Can suggest data dictionary elements.
			dict		: ':role:dict',		// Can manage data dictionary.
			commit		: ':role:commit',	// Can commit harmonised datasets.
			query		: ':role:query',	// Can query data.
			download	: ':role:download'	// Can download data.
		}
	},

	//
	// Environment.
	//
	environment: {
		auth : {
			// path		 : '/data/auth.json',
			algo		 : 'HS384'
		},
		language		 : "ISO:639:3:eng",
		page			 : 4096,
		buffer			 : 819200,
		msg_sep			 : ' '
	},

	//
	// Interface.
	//
	interface: {
		response : {
			err : 'error',
			msg : 'message',
			data : 'data'
		}
	},

	//
	// Traversal options.
	//
	traverse: {
		param : {
			id			: 'id',				// Parameters are document _id.
			key			: 'key',			// Parameters are document _key.
			var			: 'var',			// Parameters are variable name.
			doc			: 'doc'				// Parameters are the document.
		},
		result : {
			id			: 'id',				// The document _id.
			key			: 'key',			// The document _key.
			var			: 'var',			// The document variable name.
			doc			: 'doc',			// The document.
			enum		: 'enum'			// The combination of term and edge.
		}
	},

	//
	// Errors.
	//
	error: {
		MissingCollection	:  1,
		CannotSession		:  2,
		UserNotFound		:  3,
		BadPassword			:  4,
		CannotSaveAdmin		:  5,
		AdminFirstUser		:  6,
		UserMustBeManaged	:  7,
		CannotManageUsers	:  8,
		CannotCreateAdmin	:  9,
		CannotUseApp		: 10,
		InvalidInputFormat	: 11,
		InvalidOutputFormat	: 12,
		InvalidRootDataType	: 13
	}
});

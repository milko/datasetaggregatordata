'use strict';

//
// Frameworks.
//
const fs = require('fs');							// File system utilities.
const db = require('@arangodb').db;					// Database framework.
const crypto = require('@arangodb/crypto');			// Cryptographic functions.
const createAuth = require('@arangodb/foxx/auth');	// Authentication framework.

//
// Application.
//
const K = require( './Constant' );					// Application constants.
const Utils = require( './Utils' );					// Application utilities.
const MyError = require( './Error' );				// Error class.
const Schema = require( './Schema' );				// Schema class.
const Dictionary = require( './Dictionary' );		// Dictionary class.
const Application = require( './Application' );		// Application functions.

//
// Globals.
//
const kCollection = db._collection( K.collection.user.name );

/**
 * Users management
 *
 * This object contains functions and helpers used to manage users.
 */
module.exports = {

	/**
	 * Handlers
	 *
	 * Handler functions.
	 */
	handlers : {

		/**
		 * Who am I?
		 *
		 * Return the current user record, if there is a current user, or
		 * { username : null } if there is no current user.
		 *
		 * @param theRequest	{Object}	The current request.
		 * @param theResponse	{Object}	The current response.
		 */
		whoami : ( theRequest, theResponse ) =>
		{
			if( theRequest.application.user )
				theResponse.send( theRequest.application.user );					// ==>
			else
				theResponse.send({ username : null });								// ==>

		},	// whoami

		/**
		 * Login
		 *
		 * Login user.
		 *
		 * Logs user in and returns its record: { user ; <user> }.
		 *
		 * @param theRequest	{Object}	username and password.
		 * @param theResponse	{Object}	The user.
		 */
		login : ( theRequest, theResponse ) =>
		{
			//
			// Get credentials.
			//
			const code = theRequest.body.username;
			const pass = theRequest.body.password;

			//
			// Locate user.
			//
			const key = {};
			key[ K.user.field.code ] = code;
			const user =
				db._collection( K.collection.user.name )
					.firstExample( key );

			//
			// Handle user not found.
			//
			if( user === null )
				theResponse.throw(
					404,
					new MyError(
						'AuthFailed',						// Error name.
						K.error.UserNotFound,				// Error code.
						theRequest.application.language,	// Error language.
						code								// Error data.
					)
				);																// !@! ==>

			//
			// Check credentials.
			//
			const auth = createAuth();
			const valid = auth.verify( user.auth, pass );
			if( ! valid )
				theResponse.throw(
					403,
					new MyError(
						'AuthFailed',						// Error name.
						K.error.BadPassword,				// Error code.
						theRequest.application.language		// Error language.
					)
				);																// !@! ==>

			//
			// Login user.
			//
			theRequest.session.uid = user._id;
			theRequest.session.data = {};
			theRequest.sessionStorage.save( theRequest.session );

			//
			// Copy user to request.
			//
			theRequest.application.user = user;

			theResponse.send( user );												// ==>

		},	// login

		/**
		 * Logout
		 *
		 * Logout user and return former user: { user ; <former user> }.
		 *
		 * @param theRequest	{Object}	Current request.
		 * @param theResponse	{Object}	Current response.
		 */
		logout : ( theRequest, theResponse ) =>
		{
			//
			// Logout user.
			//
			theRequest.session.uid = null;
			theRequest.session.data = {};
			theRequest.sessionStorage.save( theRequest.session );

			//
			// Save current user.
			//
			const user = theRequest.application.user;

			//
			// Reset user in request.
			//
			theRequest.application.user = null;

			if( user !== null )
				theResponse.send( user );											// ==>
			else
				theResponse.send({ username : null });								// ==>

		},	// logout

		/**
		 * Signin
		 *
		 * These handlers manage user signin.
		 */
		signin : {

			/**
			 * Create administrator
			 *
			 * This service will create the system administrator user.
			 *
			 * It expects the following parameters from the body:
			 * 	- name:		The user name.
			 * 	- email:	The user e-mail.
			 * 	- language:	The user's preferred language.
			 *
			 * The service also expects the authentication token as a path parameter.
			 *
			 * The service will return the newly created administrator record, or
			 * raise an exception if there is an error.
			 *
			 * @param theRequest	{Object}	Current request.
			 * @param theResponse	{Object}	Current response.
			 */
			admin : ( theRequest, theResponse ) =>
			{
				//
				// Create administrator.
				//
				const user = {};
				user[ K.user.field.code ]  = K.user.sysadm;
				user[ K.user.field.name ]  = theRequest.body[ K.user.field.name ];
				user[ K.user.field.email ] = theRequest.body[ K.user.field.email ];
				user[ K.user.field.lang ]  = theRequest.body[ K.user.field.lang ];
				user[ K.user.field.rank ]  = K.user.rank.sys;

				//
				// Set roles.
				//
				user[ K.user.field.role ] =
					Schema.getEnumList(
						theRequest,
						'kEnumRole',
						null,
						K.traverse.param.var,
						K.traverse.result.key,
						null,
						null,
						false,
						true,
						false
					);
				if( user[ K.user.field.role ].length === 0 )
					theResponse.throw(
						500,
						new MyError(
							'NoRoles',						// Error name.
							K.error.CannotCreateAdmin,		// Error code.
							theRequest.application.language	// Error language.
						)
					);															// !@! ==>

				//
				// Create authorisation data.
				//
				const auth = createAuth();
				user[ K.user.field.auth ]
					= auth.create( theRequest.body[ K.user.param.pass ] );

				//
				// Save user.
				//
				try
				{
					//
					// Insert user.
					//
					const meta = kCollection.insert( user );

					//
					// Update session.
					//
					theRequest.session.uid = meta._id;
					theRequest.session.data = {};
					theRequest.sessionStorage.save( theRequest.session );
				}
				catch( error )
				{
					theResponse.throw(
						500,
						new MyError(
							'NoInsertUser',					// Error name.
							K.error.CannotSaveAdmin,		// Error code.
							theRequest.application.language	// Error language.
						)
					);															// !@! ==>
				}

				//
				// Save user in request.
				//
				delete user.auth;						// Hide authorisation data.
				theRequest.application.user = user;		// Set user.

				theResponse.send( user );											// ==>

			}	// admin

		}	// signin

	},	// handlers

	/**
	 * Middleware
	 *
	 * Middleware functions.
	 */
	middleware : {

		/**
		 * Assertion middleware
		 *
		 * This group of middleware handles assertions.
		 */
		assert : {

			/**
			 * Check init parameters
			 *
			 * This middleware will check if the provided parameters are correct.
			 *
			 * @param theRequest	{function}	The request.
			 * @param theResponse	{function}	The response.
			 * @param theNext		{function}	The next middleware/handler.
			 */
			noUsers : ( theRequest, theResponse, theNext ) =>
			{
				//
				// Ensure there are no users.
				//
				if( kCollection.count() !== 0 )
					theResponse.throw(
						409,
						new MyError(
							'HasUsers',						// Error name.
							K.error.AdminFirstUser,			// Error code.
							theRequest.application.language	// Error language.
						)
					);															// !@! ==>

				//
				// Call next.
				//
				theNext();

			},	// noUsers

			/**
			 * Check for user creation
			 *
			 * This middleware will check if the current user can create users.
			 *
			 * @param theRequest	{function}	The request.
			 * @param theResponse	{function}	The response.
			 * @param theNext		{function}	The next middleware/handler.
			 */
			manage : ( theRequest, theResponse, theNext ) =>
			{
				//
				// Ensure there is a current user.
				//
				if( ! theRequest.application.user )
					theResponse.throw(
						403,
						new MyError(
							'NoCurrentUser',				// Error name.
							K.error.UserMustBeManaged,		// Error code.
							theRequest.application.language	// Error language.
						)
					);															// !@! ==>

				//
				// Ensure user can manage.
				//
				if( ! theRequest.use.role.includes( K.user.role.user ) )
					theResponse.throw(
						403,
						new MyError(
							'NoManageUser',					// Error name.
							K.error.CannotManageUsers,		// Error code.
							theRequest.application.language	// Error language.
						)
					);															// !@! ==>

				//
				// Call next.
				//
				theNext();

			},	// manage

			/**
			 * Token validation
			 *
			 * These functions will validate authentication tokens.
			 */
			token : {

				/**
				 * Check path parameter
				 *
				 * This middleware expects a path parameter with name "key",
				 *
				 *
				 * This function will check if the provided path parameter corresponds
				 * to the authorisation data in the auth.json file in the data directory.
				 *
				 * The function assumes the path parameter is there.
				 *
				 * @param theRequest	{function}	The request.
				 * @param theResponse	{function}	The response.
				 * @param theNext		{function}	The next middleware/handler.
				 */
				admin : ( theRequest, theResponse, theNext ) =>
				{
					//
					// Get authorisation file.
					//
					const file = module.context.basePath
							   + fs.pathSeparator + 'data'
							   + fs.pathSeparator + 'auth.json';

					//
					// Check if file exists.
					//
					if( ! fs.isFile( file ) )
						theResponse.throw(
							404,
							new MyError(
								'NoAuthFile',					// Error name.
								K.error.CannotCreateAdmin,		// Error code.
								theRequest.application.language	// Error language.
							)
						);														// !@! ==>

					//
					// Load authorisation data.
					//
					let auth = null;
					try
					{
						auth = JSON.parse( fs.read( file ) );
					}
					catch( error )
					{
						theResponse.throw(
							500,
							new MyError(
								'NoParseAuthFile',				// Error name.
								K.error.CannotCreateAdmin,		// Error code.
								theRequest.application.language	// Error language.
							)
						);														// !@! ==>
					}

					//
					// Check authentication data.
					//
					if( (auth === null)
					 || (! auth.hasOwnProperty( 'admin' ))
					 || (! auth.admin.hasOwnProperty( 'code' ))
					 || (! auth.admin.hasOwnProperty( 'pass' )) )
						theResponse.throw(
							500,
							new MyError(
								'BadAuthFormat',				// Error name.
								K.error.CannotCreateAdmin,		// Error code.
								theRequest.application.language	// Error language.
							)
						);														// !@! ==>

					//
					// Decode token.
					//
					try
					{
						//
						// Decode.
						//
						const decoded =
							Utils.auth.decode(
								auth.admin.key,					// Key.
								theRequest.pathParams.token		// Token.
							);

						//
						// Validate.
						//
						if( (decoded === null)
						 || (! decoded.hasOwnProperty( 'code' ))
						 || (! decoded.hasOwnProperty( 'pass' ))
						 || (decoded.code !== auth.admin.code)
						 || (decoded.pass !== auth.admin.pass))
							theResponse.throw(
								403,
								new MyError(
									'AuthFailed',					// Error name.
									K.error.CannotCreateAdmin,		// Error code.
									theRequest.application.language	// Error language.
								)
							);													// !@! ==>
					}
					catch( error )
					{
						theResponse.throw( 400, error );						// !@! ==>
					}

					//
					// Call next.
					//
					theNext();

				}	// admin

			}	// token

		}	// assert

	}	// middleware

};

'use strict';

//
// Frameworks.
//
const db = require('@arangodb').db;
const aql = require('@arangodb').aql;
const errors = require('@arangodb').errors;
const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;

//
// Application.
//
const K = require( './Constant' );					// Application constants.
const MyError = require( './Error' );				// Custom errors.

/**
 * Data dictionary class
 *
 * This class implements data dictionary helpers.
 */
class Dictionary
{
	/**
	 * Get document by format
	 *
	 * This method will return a document selected according to the provided
	 * input format and in the provided output format. If you provide an array,
	 * the result will be an array.
	 *
	 * The current service request is required for selecting the desired language
	 * or other eventual environment parameters.
	 *
	 * 'theReference' is a reference to a document that can be provided in the
	 * following formats, corresponding to the value of 'theInput':
	 * 	- id:	As the term _id (should match the collection).
	 * 	- key:	As the term _key.
	 * 	- var:	As the term variable name.
	 * 	- doc:	As the term document (_rev mismatches will raise an exception).
	 * If the reference is provided as an array, the result will be an array.
	 *
	 * 'theCollection' is the collection name; it can be omitted, if the reference
	 * is a dcument _id.
	 *
	 * The result will be returned in the format corresponding to the value of
	 * 'theOutput:
	 * 	- id:	The document _id.
	 * 	- key:	The document _key.
	 * 	- var:	The document variable name.
	 * 	- doc:	The document document.
	 *
	 * 'theLanguage' can be used to restrict the label, definition, description,
	 * note and example properties to a specific language: if a string is
	 * provided, it will be considered as the language code (_key); if true is
	 * provided, the language will be taken from the current request; if you
	 * provide null, the language will be ignored. If there is no match for the
	 * language, the corresponding property will remain unchanged.
	 *
	 * If 'doDictionary' is true, the result will be an object whose key will be
	 * the value provided as reference and the value will be the expected value.
	 * If you provide a document as reference, the key will be its _id.
	 *
	 * By default the reference is expected to be the variable name and the
	 * result will be the document.
	 *
	 * If the document is not found, the method will return null or an empty
	 * array or object; any other error will raise a exception.
	 *
	 * @param theRequest	{Object}			Current request.
	 * @param theReference	{*}					Object reference.
	 * @param theCollection	{String}|{null}		Collection name.
	 * @param theInput		{String}			Input format.
	 * @param theOutput		{String}			Output format.
	 * @param theLanguage	{String}|{boolean}	Restrict labels to language.
	 * @param doDictionary	{boolean}			Return a dictionary.
	 */
	static getDocumentByFormat
	(
		theRequest,
		theReference,
		theCollection = null,
		theInput = 'var',
		theOutput = 'doc',
		theLanguage = null,
		doDictionary = false
	)
	{
		//
		// Init local storage.
		//
		let key = null;
		let collection = null;
		const is_array = Array.isArray( theReference );
		let result = (is_array) ? [] : null;

		//
		// If neither ID nor document:
		//
		if( (theInput !== K.traverse.param.id)
		 && (theInput !== K.traverse.param.doc) )
		{
			//
			// Set collection.
			//
			collection = db._collection( theCollection );
			if( ! collection )
				throw(
					new MyError(
						'NoDataDictionary',					// Error name.
						1,									// Message code.
						theRequest.application.language,	// Language.
						K.collection.term.name				// Error value.
					)
				);																// !@! ==>
		}

		//
		// Get document(s).
		//
		switch( theInput )
		{
			//
			// Handle _id.
			//
			case K.traverse.param.id:
				key = '_id';
				if( is_array )
				{
					for( const item of theReference )
					{
						try
						{
							const doc = db._document( item );
							result.push( JSON.parse(JSON.stringify(doc)) );	// Clone.
						}
						catch( error )
						{
							if( (! error.isArangoError)
							 || (error.errorNum !== ARANGO_NOT_FOUND) )
								throw( error );									// !@! ==>
						}
					}
				}
				else
				{
					try
					{
						const doc = db._document( theReference );
						result = JSON.parse(JSON.stringify(doc));			// Clone.
					}
					catch( error )
					{
						if( (! error.isArangoError)
						 || (error.errorNum !== ARANGO_NOT_FOUND) )
							throw( error );										// !@! ==>
					}
				}
				break;

			//
			// Handle document.
			//
			case K.traverse.param.doc:
				key = '_id';
				if( is_array )
				{
					for( const item of theReference )
					{
						try
						{
							const doc = db._document( item._id );
							result.push( JSON.parse(JSON.stringify(doc)) );	// Clone.
						}
						catch( error )
						{
							if( (! error.isArangoError)
								|| (error.errorNum !== ARANGO_NOT_FOUND) )
								throw( error );									// !@! ==>
						}
					}
				}
				else
				{
					try
					{
						const doc = db._document( theReference._id );
						result = JSON.parse(JSON.stringify(doc));			// Clone.
					}
					catch( error )
					{
						if( (! error.isArangoError)
							|| (error.errorNum !== ARANGO_NOT_FOUND) )
							throw( error );										// !@! ==>
					}
				}
				break;

			//
			// Handle _key.
			//
			case K.traverse.param.key:
				key = '_key';
				if( is_array )
				{
					const temp = collection.document( theReference );
					for( const item of temp )
					{
						if( item.hasOwnProperty( '_id' ) )
							result.push( item );
					}
				}
				else
				{
					try
					{
						result = collection.document( theReference );
					}
					catch( error )
					{
						if( (! error.isArangoError)
						 || (error.errorNum !== ARANGO_NOT_FOUND) )
							throw( error );										// !@! ==>
					}
				}
				break;

			//
			// Handle variable name.
			//
			case K.traverse.param.var:
				key = 'var';
				if( is_array )
				{
					result = db._query( aql`
							FOR item IN ${collection}
								FILTER item.\`var\` IN ${theReference}
								RETURN item
							`).toArray();
				}
				else
					result = collection.firstExample({ var : theReference });
				break;

			//
			// Invalid input format.
			//
			default:
				throw(
					new MyError(
						'InvalidParameter',					// Error name.
						InvalidInputFormat,					// Message code.
						theRequest.application.language,	// Language.
						theInput							// Error value.
					)
				);																// !@! ==>
		}

		//
		// Init dictionary result.
		//
		const dictionary = {};

		//
		// Handle result.
		//
		switch( theOutput )
		{
			//
			// Return _id.
			//
			case K.traverse.result.id:
				//
				// Handle dictionary result.
				//
				if( doDictionary )
				{
					if( is_array )
					{
						for (const item of result)
							dictionary[ item[ key ] ] = item._id;
					}
					else if( result !== null )
						dictionary[ result[ key ] ] = result._id;
					return dictionary;												// ==>
				}

				//
				// Handle array result.
				//
				if( is_array )
					return result.map( (item) => { return item._id; });				// ==>

				//
				// Handle scalar result.
				//
				return result._id;													// ==>

			//
			// Return document.
			//
			case K.traverse.result.doc:
				//
				// Restrict to language.
				//
				if( theLanguage !== null )
				{
					//
					// Init local storage.
					//
					let lang = null;

					//
					// Handle language.
					//
					if( (typeof( theLanguage ) === 'string')			// String,
					 || ( (typeof( theLanguage ) === 'object')			// or object
					   && (theLanguage.constructor === String) ) )		// string?
						lang = theLanguage;
					else
					{
						if( ( (typeof( theLanguage ) === 'boolean')		// Boolean,
						   || ( (typeof( theLanguage ) === 'object')		// or object
							 && (theLanguage.constructor === Boolean) ) )	// boolean?
						 && theLanguage )
							lang = theRequest.application.language;
					}

					//
					// Restrict language.
					//
					if( lang !== null )
					{
						if( is_array )
						{
							for( const item of result )
								this.restrictLanguage( item, lang );
						}
						else
							this.restrictLanguage( result, lang );
					}
				}

				//
				// Handle dictionary result.
				//
				if( doDictionary )
				{
					if( is_array )
					{
						for (const item of result)
							dictionary[ item[ key ] ] = item;
					}
					else if( result !== null )
						dictionary[ result[ key ] ] = result;
					return dictionary;												// ==>
				}

				//
				// Handle array or scalar.
				//
				return result;														// ==>

			//
			// Return _key.
			//
			case K.traverse.result.key:
				//
				// Handle dictionary result.
				//
				if( doDictionary )
				{
					if( is_array )
					{
						for (const item of result)
							dictionary[ item[ key ] ] = item._key;
					}
					else if( result !== null )
						dictionary[ result[ key ] ] = result._key;
					return dictionary;												// ==>
				}

				//
				// Handle array result.
				//
				if( is_array )
					return result.map( (item) => { return item._key; });			// ==>

				//
				// Handle scalar result.
				//
				return result._key;													// ==>

			//
			// Return variable name.
			//
			case K.traverse.result.var:
				//
				// Handle dictionary result.
				//
				if( doDictionary )
				{
					if( is_array )
					{
						for (const item of result)
							dictionary[ item[ key ] ] = item.var;
					}
					else if( result !== null )
						dictionary[ result[ key ] ] = result.var;
					return dictionary;												// ==>
				}

				//
				// Handle array result.
				//
				if( is_array )
					return result.map( (item) => { return item.var; });				// ==>

				//
				// Handle scalar result.
				//
				return result.var;													// ==>

			//
			// Invalid output format.
			//
			default:
				throw(
					new MyError(
						'InvalidParameter',					// Error name.
						InvalidOutputFormat,				// Message code.
						theRequest.application.language,	// Language.
						theInput							// Error value.
					)
				);																// !@! ==>
		}

	}	// getDocumentByFormat

	/**
	 * Check enumeration.
	 *
	 * This method will return true if the provided enumeration exists.
	 *
	 * It expects the enumeration value provided as the term _key.
	 * 'theBranches' is an array that may contain the list of enumeration
	 * branches (_key) to be searched: if the enumeration does not belong to any
	 * of the provided branched, the method will return false. If you provide
	 * an empty array, any term will do.
	 *
	 * @param theRequest	{Object}	The current request.
	 * @param theValue		{String}	The enumeration ID.
	 * @param theBranches	{Array}		The list of branches to filter.
	 */
	static checkEnumeration( theRequest, theValue, theBranches = [] )
	{
		//
		// Init local storage.
		//
		theValue = K.collection.term.name + '/' + theValue;

		//
		// Filter by branch.
		//
		if( theBranches.length > 0 )
		{
			//
			// Add collection name.
			//
			theBranches = theBranches.map( (item) => {
				return K.collection.term.name + '/' + item;
			});

			//
			// Query schemas.
			//
			const collection = db._collection( K.collection.schema.name );
			const result =
				db._query( aql`
					FOR item IN ${collection}
						FILTER
							( item._to   == ${theValue} OR
							  item._from == ${theValue} ) AND
							item.branches ANY IN ${theBranches}
						RETURN item._key
					`);

			return( result.count() > 0 );											// ==>
		}

		//
		// Filter terms.
		//
		return Boolean(
			db._exists( theValue )
		);																			// ==>

	}	// checkEnumeration

	/**
	 * Restrict to language
	 *
	 * This method will convert language string properties to a string by
	 * selecting the entry corresponding to the provided language.
	 *
	 * It expects the document, the properties and the language code, all
	 * matching properties will be processed and if the language is matched,
	 * the corresponding string will be set as the value of the property, if
	 * the language is not matched, the property will reamin unchanged.
	 *
	 * @param theDocument	{Object}	The document to process.
	 * @param theLanguage	{String}	The desired language.
	 */
	static restrictLanguage( theDocument, theLanguage )
	{
		//
		// Check document.
		//
		if( theDocument !== null )
		{
			//
			// Init local storage.
			//
			const properties = [ 'label', 'definition', 'description', 'note', 'example' ];

			//
			// Iterate properties.
			//
			for( const property of properties )
			{
				//
				// Handle property.
				//
				if( theDocument.hasOwnProperty( property )
					&& theDocument[ property ].hasOwnProperty( theLanguage ) )
					theDocument[ property ] = theDocument[ property ][ theLanguage ];
			}
		}

	}	// restrictLanguage

	/**
	 * List root data types.
	 *
	 * This method will return the variable names of all root data types.
	 *
	 * @returns {string[]}	List of root data type variable names.
	 */
	static listRootDataTypes()
	{
		return [
			'kTypeDataAny',			// Any type.
			'kTypeDataTxt',			// Text and strings.
			'kTypeDataStamp',		// Time stamp.
			'kTypeDataNum',			// Generic number.
			'kTypeDataInt',			// Integer number.
			'kTypeDataFloat',		// Floating point number.
			'kTypeDataRange',		// Range.
			'kTypeDataRef',			// Object reference.
			'kTypeDataTerm',		// Term reference (_key).
			'kTypeDataField',		// Descriptor (gid) reference.
			'kTypeDataStruct',		// Object structure.
			'kTypeDataGeojson'		// GeoJSON object structure.
		];																			// ==>

	}	// listRootDataTypes

	/**
	 * List type validation fields.
	 *
	 * This method will return the list of fields present in data type terms
	 * that can be used for validation purposes.
	 *
	 * @returns {string[]}	List of data type validation field variable names.
	 */
	static listTypeValidationFields()
	{
		return [
			'kRank',				// User rank.
			'kRole',				// User roles.
			'kTraversal',			// Edge graph traversal direction.
			'kLength',				// String length range.
			'kRegex',				// String regular expression.
			'kRange',				// Range.
			'kStatus',				// Object status.
			'kAccess'				// Value access status.
		];																			// ==>

	}	// listTypeValidationFields

	/**
	 * List descriptor validation fields.
	 *
	 * This method will return the list of fields present in descriptors
	 * that can be used for validation purposes.
	 *
	 * @returns {string[]}	List of descriptor validation field variable names.
	 */
	static listDescriptorValidationFields()
	{
		return [
			'kKind',				// Data kind.
			'kType',				// Data type.
			'kFormat',				// Data format.
			'kSize',				// Data size range.
			'kLength',				// Data length range.
			'kRegex',				// String regular expression.
			'kRole',				// User roles.
			'kRange',				// Range.
			'kDecimals',			// Significant decimals.
			'kEnumTerm',			// Enumerations list.
			'kDeploy',				// Implementation status.
			'kStatus',				// Object status.
			'kAccess',				// Value access status.
			'kUsage'				// Usage status.
		];																			// ==>

	}	// listDescriptorValidationFields
}

module.exports = Dictionary;

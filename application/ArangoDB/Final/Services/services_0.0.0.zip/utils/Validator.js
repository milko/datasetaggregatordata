'use strict';

//
// Frameworks.
//
const db = require('@arangodb').db;
const aql = require('@arangodb').aql;
const Joi = require('joi');
const errors = require('@arangodb').errors;
const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;

//
// Application.
//
const K = require( './Constant' );					// Application constants.
const MyError = require( './Error' );				// Custom errors.
const Schema = require( './Schema' );				// Schema object.
const Dictionary = require( './Dictionary' );		// Dictionary object.

/**
 * Validator class
 *
 * This class implements validation helpers.
 */
class Validator
{
	/**
	 * Constructor
	 *
	 * The constructor initialises the object with the following members:
	 *
	 * 	types:			A dictionary of data types where:
	 * 		key:		The type term _key.
	 * 		value:		Data type information:
	 * 		- data:		The type rank, role, traversal, length, regex, range,
	 * 					status and access.
	 * 		- val:		The type validator.
	 *
	 * 	fields:			A dictionary of descriptors where:
	 * 		key:		The descriptor _key.
	 * 		value:		The following object:
	 * 		- des:		The descriptor kind, type, format, size, length, regex,
	 * 					range, decimals, terms, deploy, status, access, usage.
	 * 		- val:		The descriptor validator.
	 *
	 * 	constants:		A dictionary of default descriptor constants where:
	 * 		key:		The descriptor variable name.
	 * 		value:		The descriptor _key.
	 *
	 *	branch:			The data type branch _key.
	 *
	 * Types and descriptors are filled as validation requests are provided to
	 * the object, descriptor constants are initialised with the default
	 * descriptors.
	 */
	constructor( theRequest )
	{
		//
		// Init types list.
		// Load root data types by default.
		//
		this.types = {};
		const roots =
			Dictionary.getDocumentByFormat(
				theRequest,						// Current request.
				Dictionary.listRootDataTypes(),	// List of root data types.
				K.collection.term.name,			// Terms collection.
				K.traverse.param.var			// Input format.
			);
		for( const root of roots )
		{
			this.types[ root._key ] = { data : {} };
			switch( root.var )
			{
				case 'kTypeDataAny':
					this.types[ root._key ].val = Joi.any();
					break;
				case 'kTypeDataTxt':
					this.types[ root._key ].val = Joi.string();
					break;
				case 'kTypeDataStamp':
					this.types[ root._key ].val = Joi.date().timestamp();
					break;
				case 'kTypeDataNum':
				case 'kTypeDataFloat':
					this.types[ root._key ].val = Joi.number();
					break;
				case 'kTypeDataInt':
					this.types[ root._key ].val = Joi.number().integer();
					break;
				case 'kTypeDataRange':
					this.types[ root._key ].val = Joi.array().ordered(
						Joi.number().required(),
						Joi.number().required(),
						Joi.boolean().required(),
						Joi.boolean().required());
					break;
				case 'kTypeDataRef':
				case 'kTypeDataTerm':
				case 'kTypeDataField':
					this.types[ root._key ].val = Joi.string();
					break;
				case 'kTypeDataStruct':
				case 'kTypeDataGeojson':
					this.types[ root._key ].val = Joi.object();
					break;
				default:
					throw(
						new MyError(
							'InvalidParameter',					// Error name.
							InvalidRootDataType,				// Message code.
							theRequest.application.language,	// Language.
							root.var							// Error value.
						)
					);																// !@! ==>
			}
		}

		//
		// Init descriptors list.
		//
		this.fields = {};

		//
		// Init descriptor constants.
		//
		this.constants = {};
		const result =
			db._collection( K.collection.descriptor.name )
				.byExample({ deploy : ":state:application:default" });
		for( const item of result )
			this.constants[ item.var ] = item._key;

		//
		// Init data type branch.
		//
		this.branch =
			Dictionary.getDocumentByFormat(
				theRequest,
				'kTypeData',
				K.collection.term.name
			)._key;

	}	// constructor

	/**
	 * Get validator
	 *
	 * This method will return a Joi object corresponding to the provided
	 * descriptor.
	 *
	 * If the descriptor is not found, the method will return a generic
	 * validator.
	 *
	 * @param theRequest	{Object}	The current request.
	 * @param theDescriptor	{String}	The descriptor _key.
	 * @returns {Joi}					The validator object.
	 */
	getValidator( theRequest, theDescriptor )
	{
		//
		// Get validator.
		//
		if( this.descriptors.hasOwnProperty( theDescriptor ) )
			return this.descriptors[ theDescriptor ].val;							// ==>

		//
		// Load descriptor.
		//
		let descriptor = null;
		try
		{
			descriptor =
				db._collection( K.collection.descriptor.name )
					.document( theDescriptor );
		}
		catch( error )
		{
			if( (! error.isArangoError)
			 || (error.errorNum !== ARANGO_NOT_FOUND) )
				throw( error );													// !@! ==>
			return Joi.any();														// ==>
		}

		//
		// Get data type.
		//
		const type =
			Schema.getEnumPath(
				theRequest,							// Current request.
				this.type_branch,					// Data type branch.
				descriptor[ this.constants.kType ],	// Data type.
				null,								// Set to branch.
				K.traverse.param.key,				// Provided leys.
				K.traverse.result.doc,				// Return documents.
				false,								// Don't include root.
				true,								// Restrict to choices.
				false								// Don't restrict languages.
			);

		//
		// Process data type.
		//
		const validator = this.processDataType( theRequest, type );

		return validator;

	}	// getValidator

	processDataType( theRequest, theType )
	{
		//
		// Init local storage.
		//
		let type = null;

		//
		// Handle root type.
		//
		type = theType.pop();
		while( type )
		{
			switch( type.var )
			{
			}
		}

	}	// processDataType

}	// Validator.

module.exports = Validator;

'use strict';

//
// Frameworks.
//
const fs = require('fs');
const db = require('@arangodb').db;
const crypto = require('@arangodb/crypto');

//
// Error helpers.
//
const httpError = require('http-errors');
const status = require('statuses');
const errors = require('@arangodb').errors;

const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;

const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

//
// Application.
//
const K = require( './Constant' );				// Application constants.
const MyError = require( './Error' );			// Error object.
const Collection = require( './Collection' );	// Collections lists.

/**
 * Utilities
 *
 * This object provides a series of general purpose utilities, ll functions
 * return a value as the result and throw exceptions on errors. The functions
 * will generally let exceptions fall through and eventually create custom
 * errors when the condition requires the caller to be informed.
 *
 * These are the functions:
 *
 * file.collection.import:
 * 	Import data into a collection from a file, it expects the collection name
 * 	as the parameter and returns the number of records imported. File lines that
 * 	cannot be parsed into JSON will be ignored, all other errors will be
 * 	forwarded.
 *
 * auth.data:
 * 	Will return the authentication data as an object.
 *
 * auth.encode:
 * 	Will encode the provided object into a token using the provided key.
 *
 * auth.decode:
 * 	Will decode the provided token into an object using the provided key.
 */
module.exports =
{
	/**
	 * Files
	 *
	 * File utility functions.
	 */
	file :
	{
		/**
		 * Collections
		 *
		 * Collection dump files utilities.
		 */
		collection :
		{
			/**
			 * Prepare dump for restore
			 *
			 * This function will check if there is a dump file corresponding to
			 * the provided collection name, if that is the case, it will return
			 * the path in the result value.
			 *
			 * The function will first check if a json or zip file exists, in the
			 * first case it will return its path, in the second case it will
			 * unzip the file and return its path.
			 *
			 * If no file corresponding to the provided collection name exists,
			 * the result value will be null.
			 *
			 * The function will parse each line into a JSON expression, if the
			 * line cannot be converted, it will be skipped and no error will be
			 * thrown.
			 *
			 * @param theName	{String}	The collection name.
			 * @returns {Number}			The number of records imported.
			 */
			import : ( theName ) =>
			{
				//
				// Init result.
				//
				let count = 0;

				//
				// Init paths.
				//
				const path = module.context.basePath + fs.pathSeparator + 'data';
				const filename = theName + '.json';
				const file = path + fs.pathSeparator + filename;

				//
				// Check file.
				//
				if( fs.isFile( file ) )
				{
					//
					// Init local storage.
					//
					const collection = db._collection( theName );
					const JsonLReader = require( '../utils/JsonLReader' );
					const reader = new JsonLReader( file );

					//
					// Iterate file lines.
					//
					let current = reader.readLinesBySize();
					while( current !== null )
					{
						//
						// Iterate all lines.
						//
						for( const line of current )
						{
							//
							// Convert to JSON.
							//
							let doc = null;
							try
							{
								doc = JSON.parse( line );
							}
							catch( error )
							{
								// nothing?
							}

							//
							// Insert document.
							//
							if( doc )
							{
								collection.save( doc );
								count++;
							}
						}

						//
						// Next chunk.
						//
						current = reader.readLinesBySize();
					}
				}
				else
					return null;													// ==>

				return count;														// ==>

			}	// import

		}	// collection

	},	// file

	/**
	 * Authentication
	 *
	 * Authentication utilities.
	 */
	auth : {

		/**
		 * Create authorisation object
		 *
		 * This function will return the authorisation object,
		 * it is structured as follows:
		 * 	admin:	An object containing the system administrator codes.
		 * 		key:	The token key.
		 * 		code:	The code.
		 * 		pass:	The password.
		 * 	user:	An object containing the user codes.
		 * 		key:	The token key.
		 * 		code:	The code.
		 * 		pass:	The password.
		 *
		 * @returns {Object}				The authorisation object.
		 */
		data : function()
		{
			//
			// Init local storage.
			//
			const auth = { admin : {}, user : {} };

			//
			// Set administrator data.
			//
			auth.admin.key = crypto.genRandomAlphaNumbers( 16 );
			auth.admin.code = crypto.genRandomAlphaNumbers( 16 );
			auth.admin.pass = crypto.genRandomAlphaNumbers( 16 );

			//
			// Set user data.
			//
			auth.user.key = crypto.genRandomAlphaNumbers( 16 );
			auth.user.code = crypto.genRandomAlphaNumbers( 16 );
			auth.user.pass = crypto.genRandomAlphaNumbers( 16 );

			return auth;															// ==>

		},	// file

		/**
		 * Encode object
		 *
		 * This function will return a token encoding
		 * the provided object with the provided key.
		 *
		 * The function will convert the object into a JSON string and encode
		 * it using the algorythm in the environment.auth.algo constant.
		 *
		 * All exceptions are forwarded.
		 *
		 * @param theKey	{String}	The encoding key.
		 * @param theObj	{Object}	The object to encode.
		 * @returns {String}			The token.
		 */
		encode : function( theKey, theObj )
		{
			//
			// Encode.
			//
			return(
				crypto.jwtEncode(
					theKey,						// Encoding key.
					JSON.stringify( theObj ),	// Convert object to string.
					K.environment.auth.algo		// Encoding algotythm.
				)
			);																		// ==>

		},	// encode

		/**
		 * Decode token
		 *
		 * This function expects the token to be an encoded object,
		 * it expects the key and the token.
		 *
		 * @param theKey	{String}	The key.
		 * @param theToken	{String}	The token.
		 * @returns {Object}|null		The decoded object, or null.
		 */
		decode : function( theKey, theToken )
		{
			//
			// Decode.
			//
			try
			{
				const msg = crypto.jwtDecode( theKey, theToken );
				const obj = JSON.parse( msg );

				return( obj );														// ==>
			}
			catch( error )
			{
				throw( error );													// !@! ==>
			}

		}	// decode

	}	// auth
};

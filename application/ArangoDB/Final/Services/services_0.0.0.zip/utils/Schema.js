'use strict';

//
// Frameworks.
//
const db = require('@arangodb').db;
const aql = require('@arangodb').aql;
const errors = require('@arangodb').errors;
const traversal = require("@arangodb/graph/traversal");
const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;

//
// Application.
//
const K = require( './Constant' );
const MyError = require( './Error' );
const Dictionary = require( './Dictionary' );


/**
 * Data dictionary schema class
 *
 * This class implements schema helpers.
 *
 * The class expects all required collections to exist.
 */
class Schema
{
	/**
	 * Get enumeration list
	 *
	 * This method will traverse the enumeration from 'theRoot' root in the
	 * 'theBranch' branch and return the list of elements.
	 *
	 * The current service request is required for selecting the desired language
	 * or other eventual environment parameters.
	 *
	 * 'theRoot' determines which element will be the graph root and 'theBranch'
	 * determines which branch to follow; if the latter is omitted, it will be
	 * set to the value of the root.
	 *
	 * 'theParams' parameter determines in what format both the root and branch
	 * were provided:
	 * 	- id:	As the term _id.
	 * 	- key:	As the term _key.
	 * 	- var:	As the term variable name.
	 * 	- doc:	As the term document.
	 *
	 * 'theResult' parameter determines what the method will return:
	 * 	- id:	The term _id.
	 * 	- key:	The term _key.
	 * 	- var:	The term variable name.
	 * 	- doc:	The term document.
	 * 	- enum:	A combination of the term and edge.
	 *
	 * If 'theDepth' is provided, it will be used as the maximum depth.
	 *
	 * If 'doRoot' is false, the root will be omitted.
	 *
	 * If 'doChoices' is true, only the enumeration choices will be returned.
	 *
	 * If 'doLanguage' is true, label, definition, description, note and example
	 * will contain the string in the provided language, if available.
	 *
	 * @param theRequest	{Object}					The current service request.
	 * @param theRoot		{Object}|{String}			Graph root element.
	 * @param theBranch		{Object}|{String}|{null}	Graph branch.
	 * @param theParams		{String}					Parameters format.
	 * @param theResult		{String}					Result format.
	 * @param theMaxDepth	{Number}|{null}				Maximum traversal depth.
	 * @param theMinDepth	{Number}|{null}				Minimum traversal depth.
	 * @param doRoot		{boolean}					Include root.
	 * @param doChoices		{boolean}					Restrict to choices.
	 * @param doLanguage	{boolean}					Restrict labels to current language.
	 * @returns {Array}									List of enumeration elements.
	 */
	static getEnumList
	(
		theRequest,
		theRoot,
		theBranch = null,
		theParams = 'var',
		theResult = 'doc',
		theMaxDepth = null,
		theMinDepth = null,
		doRoot = true,
		doChoices = false,
		doLanguage = false
	)
	{
		//
		// Get root, branch and predicates.
		//
		let root = null;
		let branch = null;
		let pred_choice = null;
		let pred_category = null;
		try
		{
			//
			// Get root.
			//
			root =
				Dictionary.getDocumentByFormat(
					theRequest,
					theRoot,
					K.collection.term.name,
					theParams,
					K.traverse.result.doc
				);

			//
			// Get branch.
			//
			if( theBranch !== null )
				branch =
					Dictionary.getDocumentByFormat(
						theRequest,
						theBranch,
						K.collection.term.name,
						theParams,
						K.traverse.result.doc
					);
			else
				branch = root;

			//
			// Get predicates.
			//
			pred_choice =
				Dictionary.getDocumentByFormat(
					theRequest,
					'kPredicateEnumOf',
					K.collection.term.name,
					K.traverse.param.var,
					K.traverse.result.id
				);
			pred_category =
				Dictionary.getDocumentByFormat(
					theRequest,
					'kPredicateCategoryOf',
					K.collection.term.name,
					K.traverse.param.var,
					K.traverse.result.id
				);
		}
		catch( error )
		{
			throw( error );														// !@! ==>
		}

		//
		// Init result.
		//
		const result = { list : [] };
		result.edges = [];

		//
		// Init configuration.
		//
		const config =  {
			datasource	: traversal.collectionDatasourceFactory( K.collection.schema.name ),
			strategy	: "depthfirst",
			expander	: traversal.inboundExpander,
			uniqueness	: {
				edges		: 'path',
				vertices	: 'path'
			},

			visitor		: this.enumListVisitor,
			filter		: this.enumListFilter,
			expandFilter: this.enumListExpandFilter,
			sort		: this.enumListSort,

			custom		: {
				dir			: 'in',
				branch		: branch._id,
				predicates	: [ pred_choice, pred_category ],
				format		: theResult,
				language	: theRequest.application.language,
				doLanguage	: Boolean( doLanguage ),
				doChoices	: Boolean( doChoices ),
				doRoot		: Boolean( doRoot )
			}
		};

		//
		// Set depth.
		//
		if( theMinDepth !== null )
			config.minDepth = theMinDepth;
		if( theMaxDepth !== null )
			config.maxDepth = theMaxDepth;

		//
		// Traverse.
		//
		const traverser = new traversal.Traverser( config );
		traverser.traverse( result, root );

		return result.list;															// ==>

	}	// getEnumList

	/**
	 * Get enumeration path
	 *
	 * This method will traverse the enumeration from 'theLeaf' to 'theRoot' in
	 * 'theBranch' branch and return the list of elements.
	 *
	 * The current service request is required for selecting the desired language
	 * or other eventual environment parameters.
	 *
	 * 'theLeaf' determines which element will represent the origin of the traversal,
	 * 'theRoot' determines where the traversal will end and 'theBranch' determines
	 * the graph branch to traverse.
	 *
	 * If you omit 'theRoot', it will be set to the value of 'theBranch'.
	 *
	 * 'theParams' parameter determines in what format both the leaf, root and branch
	 * were provided:
	 * 	- id:	As the term _id.
	 * 	- key:	As the term _key.
	 * 	- var:	As the term variable name.
	 * 	- doc:	As the term document.
	 *
	 * 'theResult' parameter determines the result format:
	 * 	- id:	The term _id.
	 * 	- key:	The term _key.
	 * 	- var:	The term variable name.
	 * 	- doc:	The term document.
	 * 	- enum:	A combination of the term and edge.
	 *
	 * If 'doRoot' is false, the root will be omitted.
	 *
	 * If 'doChoices' is true, only the enumeration choices will be returned.
	 *
	 * If 'doLanguage' is true, label, definition, description, note and example
	 * will contain the string in the provided language, if available.
	 *
	 * @param theRequest	{Object}					The current service request.
	 * @param theBranch		{Object}|{String}			Graph branch.
	 * @param theLeaf		{Object}|{String}			Graph leaf element.
	 * @param theRoot		{Object}|{String}|{null}	Graph root element.
	 * @param theParams		{String}					Parameters format.
	 * @param theResult		{String}					Result format.
	 * @param doRoot		{boolean}					Include root.
	 * @param doChoices		{boolean}					Restrict to choices.
	 * @param doLanguage	{boolean}					Restrict labels to current language.
	 * @returns {Array}									List of enumeration elements.
	 */
	static getEnumPath
	(
		theRequest,
		theBranch,
		theLeaf,
		theRoot = null,
		theParams = 'var',
		theResult = 'doc',
		doRoot = true,
		doChoices = false,
		doLanguage = false
	)
	{
		//
		// Get leaf, root, branch and predicates.
		//
		let leaf = null;
		let root = null;
		let branch = null;
		let pred_choice = null;
		let pred_category = null;
		try
		{
			//
			// Get leaf.
			//
			leaf =
				Dictionary.getDocumentByFormat(
					theRequest,
					theLeaf,
					K.collection.term.name,
					theParams,
					K.traverse.result.doc
				);

			//
			// Get branch.
			//
			branch =
				Dictionary.getDocumentByFormat(
					theRequest,
					theBranch,
					K.collection.term.name,
					theParams,
					K.traverse.result.doc
				);

			//
			// Get root.
			//
			if( theRoot !== null )
				root =
					Dictionary.getDocumentByFormat(
						theRequest,
						theRoot,
						K.collection.term.name,
						theParams,
						K.traverse.result.doc
					);
			else
				root = branch;

			//
			// Get predicates.
			//
			pred_choice =
				Dictionary.getDocumentByFormat(
					theRequest,
					'kPredicateEnumOf',
					K.collection.term.name,
					K.traverse.param.var,
					K.traverse.result.id
				);
			pred_category =
				Dictionary.getDocumentByFormat(
					theRequest,
					'kPredicateCategoryOf',
					K.collection.term.name,
					K.traverse.param.var,
					K.traverse.result.id
				);
		}
		catch( error )
		{
			throw( error );														// !@! ==>
		}

		//
		// Init result.
		//
		const result = { list : [] };

		//
		// Init configuration.
		//
		const config =  {
			datasource	: traversal.collectionDatasourceFactory( K.collection.schema.name ),
			strategy	: "depthfirst",
			expander	: traversal.outboundExpander,
			order		: "preorder-expander",
			uniqueness	: {
				edges		: 'path',
				vertices	: 'path'
			},

			visitor		: this.enumPathVisitor,
			expandFilter: this.enumListExpandFilter,

			custom		: {
				dir			: 'out',
				root		: root._id,
				branch		: branch._id,
				predicates	: [ pred_choice, pred_category ],
				format		: theResult,
				language	: theRequest.application.language,
				doLanguage	: Boolean( doLanguage ),
				doChoices	: Boolean( doChoices ),
				doRoot		: Boolean( doRoot )
			}
		};


		//
		// Traverse.
		//
		const traverser = new traversal.Traverser( config );
		traverser.traverse( result, leaf );

		return result.list;															// ==>

	}	// getEnumPath

	/**
	 * Enumeration list visitor function
	 *
	 * This method will append the vertex to the 'list' element of 'theResult'
	 * in the format set in 'theConfig' custom object.
	 *
	 * @param theConfig	{Object}	The configuration object.
	 * @param theResult	{Object}	The result object (expects 'list').
	 * @param theVertex	{Object}	The current vertex.
	 * @param thePath	{Object}	The current path: { edges: [], vertices: [] }.
	 */
	static enumListVisitor( theConfig, theResult, theVertex, thePath )
	{
		//
		// Format vertex.
		//
		switch( theConfig.custom.format )
		{
			case K.traverse.result.doc:
				theResult.list.push( theVertex );
				break;

			case K.traverse.result.id:
				theResult.list.push( theVertex._id );
				break;

			case K.traverse.result.key:
				theResult.list.push( theVertex._key );
				break;

			case K.traverse.result.var:
				theResult.list.push( theVertex.var );
				break;

			case K.traverse.result.enum:
				const edge = ( thePath.edges.length > 0 )
					? thePath.edges[ thePath.edges.length - 1 ]
					: null;
				theResult.list.push( Schema.enumFormat( theConfig, edge, theVertex ) );
				break;

			default:
				throw(
					new MyError(
						'InvalidParameter',					// Error name.
						InvalidOutputFormat,				// Message code.
						theRequest.application.language,	// Language.
						theOutput							// Error value.
					)
				);																// !@! ==>
		}

	}	// enumListVisitor

	/**
	 * Enumeration path visitor function
	 *
	 * This method will append the vertex to the 'list' element of 'theResult'
	 * in the format set in 'theConfig' custom object.
	 *
	 * @param theConfig	{Object}	The configuration object.
	 * @param theResult	{Object}	The result object (expects 'list').
	 * @param theVertex	{Object}	The current vertex.
	 * @param thePath	{Object}	The current path: { edges: [], vertices: [] }.
	 * @param theEdge	{Object}	{ edge: <current edge>, vertex: <current vertex> }.
	 */
	static enumPathVisitor( theConfig, theResult, theVertex, thePath, theEdge )
	{
		//
		// Init local storage.
		//
		let edge = null;
		let vertex = null;

		//
		// Handle root.
		//
		if( theEdge.length === 0 )
		{
			//
			// Check root inclusion.
			//
			if( theConfig.custom.doRoot )
				vertex = theVertex;
		}

		//
		// Handle other elements.
		//
		else
		{
			//
			// Filter enumeration choices.
			//
			if( (! theConfig.custom.doChoices)
			 || (theEdge[ 0 ].edge.predicate === theConfig.custom.predicates[ 0 ]) )
			{
				edge = theEdge[ 0 ].edge;
				vertex = theVertex;
			}
		}

		//
		// Check vertex.
		//
		if( vertex !== null )
		{
			//
			// Restrict language.
			//
			if( theConfig.custom.doLanguage )
				Dictionary.restrictLanguage( vertex, theConfig.custom.language );

			//
			// Format vertex.
			//
			switch( theConfig.custom.format )
			{
				case K.traverse.result.doc:
					theResult.list.push( theVertex );
					break;

				case K.traverse.result.id:
					theResult.list.push( theVertex._id );
					break;

				case K.traverse.result.key:
					theResult.list.push( theVertex._key );
					break;

				case K.traverse.result.var:
					theResult.list.push( theVertex.var );
					break;

				case K.traverse.result.enum:
					theResult.list.push(
						Schema.enumFormat( theConfig, edge, vertex )
					);
					break;

				default:
					throw(
						new MyError(
							'InvalidParameter',					// Error name.
							InvalidOutputFormat,				// Message code.
							theRequest.application.language,	// Language.
							theOutput							// Error value.
						)
					);															// !@! ==>
			}
		}

	}	// enumPathVisitor

	/**
	 * Enumeration list vertex filter
	 *
	 * This method will check whether the current vertex should be included
	 * in the traversal, it will return the following values that determine whether
	 * the vertex will be included and whether the edges will be traversed:
	 * 	- undefined:			Vertex INCLUDED and connected edges TRAVERSED.
	 * 	- 'exclude':			Vertex NOT included and connected edges TRAVERSED.
	 * 	- 'prune:				Vertex NOT included and connected edges NOT traversed.
	 * 	- ['prune:, 'exclude]:	Vertex NOT included and connected edges NOT returned.
	 *
	 * @param theConfig	{Object}	The configuration object.
	 * @param theVertex	{Object}	The current vertex.
	 * @param thePath	{Object}	The current path: { edges: [], vertices: [] }.
	 * @returns {*}					The filter command.
	 */
	static enumListFilter( theConfig, theVertex, thePath )
	{
		//
		// Restrict language.
		//
		if( theConfig.custom.doLanguage )
			Dictionary.restrictLanguage( theVertex, theConfig.custom.language );

		//
		// Handle root.
		//
		if( thePath.edges.length === 0 )
		{
			if( theConfig.custom.doRoot )
				return undefined;													// ==>

			return 'exclude';														// ==>
		}

		//
		// Handle choice.
		//
		if( theConfig.custom.doChoices )
		{
			if( thePath.edges[ thePath.edges.length - 1 ].predicate
				!== theConfig.custom.predicates[ 0 ] )
				return 'exclude';													// ==>
		}

		return undefined;															// ==>

	}	// enumListFilter

	/**
	 * Enumeration list edge filter
	 *
	 * This method will filter the edges according to the following criteria:
	 * 	- branch:		If the branch does not match it will return false.
	 * 	- predicate:	The predicate must be among the enumeration's.
	 *
	 * true means follow path.
	 *
	 * @param theConfig	{Object}	The configuration object.
	 * @param theVertex	{Object}	The current vertex.
	 * @param theEdge	{Object}	The current edge.
	 * @param thePath	{Object}	The current path: { edges: [], vertices: [] }.
	 * @returns {boolean}
	 */
	static enumListExpandFilter( theConfig, theVertex, theEdge, thePath )
	{
		//
		// Restrict language.
		//
		if( theConfig.custom.doLanguage )
			Dictionary.restrictLanguage( theEdge, theConfig.custom.language );

		//
		// Check branch.
		//
		if( ! theEdge.branches.includes( theConfig.custom.branch ) )
			return false;															// ==>

		//
		// Check predicate.
		//
		if( ! theConfig.custom.predicates.includes( theEdge.predicate ) )
			return false;															// ==>

		return true;																// ==>

	}	// enumListExpandFilter

	/**
	 * Sort edges
	 *
	 * This method will sort edges according to the '_sort' field.
	 *
	 * @param theLeft	{Object}	The left edge.
	 * @param theRight	{Object}	The right edge.
	 * @returns {number}			0: equal; 1: left > right; -1.
	 */
	static enumListSort( theLeft, theRight )
	{
		if( theLeft.order < theRight.order )
			return -1;															// ==>

		if( theLeft.order > theRight.order )
			return 1;															// ==>

		return 0;																	// ==>

	}	// enumListSort

	/**
	 * Format enumeration element
	 *
	 * This method will format an enumeration element when the output format
	 * is 'enum'.
	 *
	 * It will return an object with two elements:
	 * 	- edge:		The edge to the vertex.
	 * 	- vertex:	The vertex.
	 *
	 * @param theConfig	{Object}	The configuration object.
	 * @param theEdge	{Object}	The current vertex.
	 * @param theVertex	{Object}	The current vertex.
	 * @returns {Object}			{ edge: <the edge>, vertex: <the vertex> }.
	 */
	static enumFormat( theConfig, theEdge, theVertex )
	{
		//
		// Handle edge.
		//
		if( theEdge !== null ) {
			const edge = JSON.parse( JSON.stringify( theEdge ) );
			delete edge._id;
			delete edge._rev;
			delete edge._key;
			delete edge.branches;

			return { edge : edge, vertex : theVertex };								// ==>
		}

		return { vertex : theVertex };												// ==>

	}	// enumFormat
}

module.exports = Schema;

'use strict';

//
// Frameworks.
//
const db = require('@arangodb').db;
const crypto = require('@arangodb/crypto');
const errors = require('@arangodb').errors;
const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;

//
// Application.
//
const K = require( './Constant' );					// Application constants.
const Utils = require( './Utils' );					// Application utilities.
const MyError = require( './Error' );				// Custom errors.
const Collection = require( './Collection' );		// Collection info.

/**
 * Application functions
 *
 * This object contains common application functions.
 *
 * init.collections.document():
 * 	Will create all required document collections, returns list of created
 * 	collection names.
 *
 * init.collections.edge():
 * 	Will create all required edge collections, returns list of created
 * 	collection names.
 *
 * init.collections.index():
 * 	Will update all collection indexes, returns list of collections with
 * 	indexes.
 *
 * init.data(request):
 * 	Will initialise application data in the provided request.
 *
 * init.status(request):
 * 	Will initialise the current status in the provided request,
 * 	throws if any required collection is empty.
 *
 * init.session(request):
 * 	Will initialise the current session user in the provided request,
 * 	exits if no current user is in the session.
 *
 * tear.collections.document():
 * 	Will drop all required document collections, returns list of dropped
 * 	collection names.
 *
 * tear.collections.edge():
 * 	Will drop all required edge collections, returns list of dropped
 * 	collection names.
 */
module.exports = {

	/**
	 * Initialisation
	 *
	 * Initialisation and application configuration functions.
	 */
	init : {

		/**
		 * Collections
		 *
		 * Collection initialisation and configuration functions.
		 */
		collections : {

			/**
			 * Initialise document collections
			 *
			 * This function will create and/or update the index configuration
			 * for all managed document collections.
			 *
			 * @returns {Array}					List of created collections.
			 */
			document : () =>
			{
				//
				// Init local storage.
				//
				const result = [];

				//
				// Iterate document collections.
				//
				for( const item of Collection.document )
				{
					//
					// Create document collection.
					//
					const name = item.name;
					if( ! db._collection( name ) )
					{
						//
						// Create collection.
						//
						db._createDocumentCollection( name );
						result.push( name );

						//
						// Set indexes.
						//
						for( const index of item.index )
							db._collection( name ).ensureIndex( index );
					}
				}

				return result;														// ==>

			},	// document

			/**
			 * Initialise edge collections
			 *
			 * This function will create and/or update the index configuration
			 * for all managed edge collections.
			 *
			 * @returns {Array}					List of created collections.
			 */
			edge : () =>
			{
				//
				// Init local storage.
				//
				const result = [];

				//
				// Iterate edge collections.
				//
				for( const item of Collection.graph )
				{
					//
					// Create document collection.
					//
					const name = item.name;
					if( ! db._collection( name ) )
					{
						//
						// Create collection.
						//
						db._createEdgeCollection( name );
						result.push( name );

						//
						// Set indexes.
						//
						for( const index of item.index )
							db._collection( name ).ensureIndex( index );
					}
				}

				return result;														// ==>

			},	// edge

			/**
			 * Create/update collection indexes.
			 *
			 * This function will create or update collection indexes.
			 *
			 * @returns {Array}					List of updated indexes.
			 */
			index : () =>
			{
				//
				// Init local storage.
				//
				let name = null;
				const result = [];

				try
				{
					//
					// Handle document collections.
					//
					for( const item of Collection.document )
					{
						//
						// Create document collection.
						//
						name = item.name;
						if( ! db._collection( name ) )
							db._createDocumentCollection( name );

						//
						// Check index.
						//
						if( item.index.length )
						{
							//
							// Add/update index.
							//
							for( const index of item.index )
								db._collection( name ).ensureIndex( index );

							//
							// Save to result.
							//
							result.push( name );
						}
					}

					//
					// Handle document collections.
					//
					for( const item of Collection.graph )
					{
						//
						// Create document collection.
						//
						name = item.name;
						if( ! db._collection( name ) )
							db._createEdgeCollection( name );

						//
						// Check index.
						//
						if( item.index.length )
						{
							//
							// Add/update index.
							//
							for( const index of item.index )
								db._collection( name ).ensureIndex( index );

							//
							// Save to result.
							//
							result.push( name );
						}
					}
				}

				catch( error )
				{
					throw( error );												// !@! ==>
				}

				return result;													// !@! ==>

			}	// index

		},	// collections

		/**
		 * Init application data
		 *
		 * This function will initialise the application data, this is a
		 * property in the request, named 'application', that will receive
		 * all global data needed by the service.
		 *
		 * @param theRequest	{Object}	The request.
		 */
		data : ( theRequest ) =>
		{
			//
			// Set application data property.
			//
			theRequest.application = {
				user : null,
				language : K.environment.language
			};

		},	// data

		/**
		 * Set application status
		 *
		 * This function will initialise the application status.
		 *
		 * It will first check if any of the dictionary collections are empty,
		 * in which case it will set the status to "DDICT".
		 *
		 * If the dictionary is there and a previous status is found, it will
		 * set the current status to the found one.
		 *
		 * The function will return the current status in the return property.
		 * If an exception, other than not found, is thrown when reading the
		 * current status, the return parameter will have its errors set.
		 *
		 * @param theRequest	{Object}	The request, will receive the status.
		 */
		status : ( theRequest ) =>
		{
			//
			// Check data dictionary.
			//
			for( const item of Collection.ddict )
			{
				const collection = db._collection( item.name );
				if( (! collection)
				 || (collection.count() === 0) )
					throw(
						new MyError(
							'NoDataDictionary',					// Error name.
							K.error.MissingCollection,			// Error code.
							theRequest.application.language,	// Error language.
							item.name							// Error data.
						)
					);															// !@! ==>
			}

			//
			// Init status.
			//
			theRequest.application.status = {};
			theRequest.application.status.application
				= K.setting.status.app.state.ok;

			//
			// Get current status.
			//
			const collection = db._collection( K.collection.setting.name );
			try
			{
				//
				// Get from collection.
				//
				const doc = collection.document( K.setting.status.key );

				//
				// Copy to reqyest.
				//
				theRequest.application.status.application
					= doc[ K.setting.status.app.key ];
			}
			catch( error )
			{
				//
				// Handle errors.
				//
				if( (! error.isArangoError)
					|| (error.errorNum !== ARANGO_NOT_FOUND) ) {
					throw( error );												// !@! ==>
				}

				//
				// Create new status.
				//
				try
				{
					collection.insert(
						Object.assign(
							{ _key : K.setting.status.key },
							theRequest.application.status
						)
					);
				}
				catch( error )
				{
					throw( error );												// !@! ==>
				}
			}

		},	// status

		/**
		 * Set application session
		 *
		 * This function will initialise the application session.
		 *
		 * It will first check if the current session has an active user,
		 * if that is not the case it will exit without any action.
		 *
		 * If there is a current session user, it will reqtrieve its record
		 * and set the user property of the request's application data to
		 * that user.
		 *
		 * In the process, it will also initialise the session data if necessary.
		 *
		 * @param theRequest	{Object}	The request, will receive the status.
		 */
		session : ( theRequest ) =>
		{
			//
			// Check session.
			// Should be there.
			//
			if( theRequest.hasOwnProperty( 'session' ) )
			{
				//
				// Handle user.
				// We assume here there is a session,
				// and that the session contains the uid.
				//
				if( theRequest.session.uid )
				{
					try
					{
						//
						// Read current user.
						//
						const user = db._document( theRequest.session.uid );

						delete user._id;
						delete user._key;
						delete user._rev;
						delete user.auth;

						theRequest.application.user = user;
						theRequest.application.language = user.language;

						//
						// Init session data.
						// We assume session data is there by default.
						//
						if( ! theRequest.session.data )
						{
							theRequest.session.data = {};
							theRequest.sessionStorage.save( theRequest.session );
						}
					}
					catch( error )
					{
						//
						// Handle error.
						//
						if( (!error.isArangoError)
							|| (error.errorNum !== ARANGO_NOT_FOUND) ) {
							throw( error );										// !@! ==>
						}

						//
						// Reset session.
						//
						theRequest.session.uid = null;
						theRequest.session.data = {};
						theRequest.sessionStorage.save( theRequest.session );
					}
				}

				//
				// Reset session data.
				//
				else
					theRequest.session.data = {};
			}

			//
			// Missing session.
			//
			else
				throw(
					new MyError(
						'NoSession',						// Error name.
						K.error.CannotSession,				// Error code.
						theRequest.application.language		// Error language.
					)
				);																// !@! ==>

		}	// session

	},	// init

	/**
	 * Teardown
	 *
	 * Teardown and application cleaning functions.
	 */
	tear : {

		/**
		 * Collections
		 *
		 * Collection teradown and cleaning functions.
		 */
		collections : {

			/**
			 * Drop document collections
			 *
			 * This function will drop all managed document collections.
			 */
			document : () =>
			{
				//
				// Init local storage.
				//
				const result = [];

				//
				// Iterate document collections.
				//
				for( const item of Collection.document )
				{
					//
					// Drop document collection.
					//
					const name = item.name;
					const collection = db._collection( name );
					if( collection ) {
						collection.drop();
						result.push( name );
					}
				}

				return result;														// ==>

			},	// document

			/**
			 * Initialise edge collections
			 *
			 * This function will create and/or update the index configuration
			 * for all managed edge collections.
			 */
			edge : () =>
			{
				//
				// Init local storage.
				//
				const result = [];

				//
				// Iterate document collections.
				//
				for( const item of Collection.graph )
				{
					//
					// Drop edge collection.
					//
					const name = item.name;
					const collection = db._collection( name );
					if( collection ) {
						collection.drop();
						result.push( name );
					}
				}

				return result;														// ==>

			}	// edge

		}	// collections

	}	// tear
};

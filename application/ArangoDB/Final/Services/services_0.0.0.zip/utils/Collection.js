'use strict';

//
// Application.
//
const K = require( './Constant' );		// Application constants.

/**
 * Collections management
 *
 * This object contains functions and helpers used to manage collections.
 */
module.exports = {

	//
	// Document collection.
	//
	document : [
		K.collection.setting,
		K.collection.message,
		K.collection.session,
		K.collection.log,
		K.collection.term,
		K.collection.descriptor,
		K.collection.user,
		K.collection.group,
		K.collection.study,
		K.collection.annex,
		K.collection.smart,
		K.collection.toponym,
		K.collection.shape
	],

	//
	// Edge collections.
	//
	graph : [
		K.collection.schema,
		K.collection.hierarchy,
		K.collection.link,
		K.collection.edge
	],

	//
	// Data dictionary collections.
	//
	ddict : [
		K.collection.error,
		K.collection.message,
		K.collection.term,
		K.collection.descriptor,
		K.collection.schema
	],

};

'use strict';

//
// Frameworks.
//
const db = require('@arangodb').db;		// Database framework.

//
// Application.
//
const K = require( './Constant' );		// Application constants.

//
// Globals.
//
const kCollection = db._collection( K.collection.log.name );

/**
 * Log management
 *
 * This object contains functions and helpers used to write log entries.
 *
 * Methods should not raise exceptions.
 */
module.exports = {

	/**
	 * Write log entry
	 *
	 * The function will write the log entry
	 * if there is a current session
	 * and if the session contains a logged user.
	 *
	 * @param theStart		{Number}	The start timestamp.
	 * @param theEnd		{Number}	The end timestamp.
	 * @param theRequest	{Object}	The request.
	 * @param theResponse	{Object}	The response.
	 */
	write : function( theStart, theEnd, theRequest, theResponse )
	{
		//
		// Check collection.
		//
		if( kCollection )
		{
			//
			// Check user.
			//
			if( theRequest.session.uid )
			{
				//
				// Set document.
				//
				const doc = { type : 'event' };

				//
				// Set timestamps and response status code.
				//
				doc[ K.log.start ]	= theStart;
				doc[ K.log.end ]	= theEnd;
				doc[ K.log.status ]	= theResponse.statusCode;

				//
				// Set user info.
				//
				doc[ K.log.user ] = theRequest.session.uid;
				doc[ K.log.rank ] = theRequest.application.user.rank;
				doc[ K.log.role ] = theRequest.application.user.role;

				//
				// Set cookie key.
				//
				if( theRequest.session.hasOwnProperty( '_key' ) )
					doc[ K.log.session ] = theRequest.session._key;

				//
				// Set path and remote address info.
				//
				doc[ K.log.path ] = theRequest.path;
				doc[ K.log.ip ]	  = theRequest.remoteAddress;
				doc[ K.log.port ] = theRequest.port;

				//
				// Save log entry.
				//
				try
				{
					kCollection.insert( doc );
				}
				catch( error )
				{
					// Ignore.
				}
			}
		}

	},	// write

	error : function( theError, theException = null )
	{
		//
		// Check collection.
		//
		if( kCollection )
		{
			//
			// Set document.
			//
			const doc = { type : 'error' };

			//
			// Set error parameters.
			//
			for( const prop of [ K.log.ename, K.log.emess, K.log.elang, K.log.edata ] )
			{
				if( theError.hasOwnProperty( prop ) )
					doc[ prop ]	= theError[ prop ];
			}

			//
			// Set exception message.
			//
			if( theException !== null )
				doc[ K.log.eexch ] = theException.message;

			//
			// Save log entry.
			//
			try
			{
				kCollection.insert( doc );
			}
			catch( error )
			{
				// Ignore.
			}
		}

	}	// error

};

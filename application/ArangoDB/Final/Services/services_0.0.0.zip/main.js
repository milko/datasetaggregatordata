'use strict';

//
// Timestamp.
//
const stamp = Date.now();

//
// Routes.
//
module.context.use('/', require('./routes/utils'), 'utils');

module.context.use('/terms', require('./routes/terms'), 'terms');
module.context.use('/descriptors', require('./routes/descriptors'), 'descriptors');
module.context.use('/settings', require('./routes/settings'), 'settings');
module.context.use('/sessions', require('./routes/sessions'), 'sessions');
module.context.use('/logs', require('./routes/logs'), 'logs');
module.context.use('/messages', require('./routes/messages'), 'messages');
module.context.use('/users', require('./routes/users'), 'users');
module.context.use('/smart', require('./routes/smart'), 'smart');
module.context.use('/schemas', require('./routes/schemas'), 'schemas');

module.context.use('/test', require('./routes/test'), 'test');

//
// Frameworks.
//
const db = require('@arangodb').db;
const sessionsMiddleware = require( '@arangodb/foxx/sessions' );

//
// Application.
//
const K = require( './utils/Constant' );						// Application constants.
const Log = require( './utils/Log' );							// Log functions.
const MyError = require( './utils/Error' );						// Error class.
const Application = require( './utils/Application' );			// Application functions.

//
// Set sessions middleware.
// Note: you should expect a session property in the request.
//
const sessions = sessionsMiddleware({
	storage: db._collection( K.collection.session.name ),		// Sessions collection.
	transport: 'cookie'											// Sessions transport.
});

module.context.use( sessions );

//
// Main middleware.
//
module.context.use(

	/**
	 * Main middleware
	 *
	 * This middleware function will initialise all required elements before
	 * calling the service handler.
	 *
	 * The whole call sequence is enclosed in a try block so that a finally
	 * may be called where the ecent will be logged.
	 *
	 * @param theRequest	{Object}	The request.
	 * @param theResponse	{Object}	The response.
	 * @param theHandler	{function}	The handler.
	 */
	function( theRequest, theResponse, theHandler )
	{
		//
		// Execute preliminary middleware and handler.
		//
		try
		{
			//
			// Init request application data.
			// Note: must not fail.
			//
			Application.init.data( theRequest );

			//
			// Init request session.
			//
			try
			{
				Application.init.session( theRequest );
				Application.init.status( theRequest );
			}
			catch( error )
			{
				theResponse.throw( 500, error );								// !@! ==>
			}

			//
			// Check status.
			//
			switch( theRequest.application.status[ K.setting.status.app.key ] )
			{
				case K.setting.status.app.state.ddict:
					theResponse.throw(
						500,
						new MyError(
							'NoDataDictionary',
							K.error.CannotUseApp,
							theRequest.application.language
						)
					);															// !@! ==>
					break;

				case K.setting.status.app.state.busy:
					theResponse.throw(
						503,
						new MyError(
							'BusyDatabase',
							K.error.CannotUseApp,
							theRequest.application.language
						)
					);															// !@! ==>
					break;
			}

			//
			// Execute handler.
			//
			theHandler();
		}

			//
			// Execute final steps.
			//
		finally
		{
			//
			// Write log entry.
			//
			Log.write( stamp, Date.now(), theRequest, theResponse );
		}
	}
);

'use strict';

/**
 * Test services
 *
 * This path is used to test services.
 */

//
// Import frameworks.
//
const dd = require('dedent');							// For multiline text.
const fs = require('fs');								// File system utilities.
const db = require('@arangodb').db;						// Database object.
const Joi = require('joi');								// Validation framework.
const crypto = require('@arangodb/crypto');				// Cryptographic functions.
const httpError = require('http-errors');				// HTTP errors.
const status = require('statuses');						// Don't know what it is.
const errors = require('@arangodb').errors;				// ArangoDB errors.
const createAuth = require('@arangodb/foxx/auth');		// Authentication framework.
const createRouter = require('@arangodb/foxx/router');	// Router class.
const jwtStorage = require('@arangodb/foxx/sessions/storages/jwt');

//
// Instantiate objects.
//
const K = require( '../utils/Constant' );				// Application constants.
const Utils = require( '../utils/Utils' );				// Utility functions.
const Application = require( '../utils/Application' );	// Application functions.

//
// Error constants.
//
const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;
const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

//
// Instantiate router.
//
const auth = createAuth();
const router = createRouter();
module.exports = router;


//
// Set router tags.
//
router.tag( 'test' );


/**
 * Ping
 *
 * The service will return pong.
 *
 * @path		/ping
 * @verb		get
 * @response	{String}	"pong".
 */
router.get(
	'/ping',
	(request, response) => { response.send( 'pong' ); },
	'ping'
)
	.response(
		200,
		[ 'application/text' ],
		"The ping response"
	)
	.summary(
		"Check if there"
	)
	.description(dd`
  Returns a ping response
`);


/**
 * Mirror GET request contents
 *
 * The service will return the GET request contents.
 *
 * @path		/echo-get
 * @verb		get
 * @response	{Object}	The request contents.
 */
router.get(
	'/echo/get',
	(request, response) => { response.send( request ); },
	'echoGET'
)
	.response(
		200,
		[ 'application/json' ],
		"Request echo"
	)
	.summary(
		"Echo GET request"
	)
	.description(dd`
  The service will return the GET request contents.
`);


/**
 * Test POST request contents
 *
 * The service will return the request contents.
 *
 * @path		/echo-post
 * @verb		get
 * @response	{Object}	The request contents.
 */
router.post(
	'/echo/post',
	(request, response) => { response.send( request ); },
	'echoPOST'
)
	.body(
		[ 'application/json' ],
		"Request contents."
	)
	.response(
		[ 'application/json' ],
		"Request echo."
	)
	.summary(
		"Echo POST request"
	)
	.description(dd`
  Returns the POST request contents.
`);


/**
 * Test get base path
 *
 * The service will return the base path.
 *
 * @path		/path/base
 * @verb		get
 * @response	{Object}	The request contents.
 */
router.get(
	'/path/base',
	(request, response) => { response.send( module.context.basePath ); },
	'echoGET'
)
	.response(
		200,
		[ 'application/text' ],
		"Base path."
	)
	.summary(
		"Returns base path"
	)
	.description(dd`
  Returns the base path.
`);


/**
 * Test get temp directory
 *
 * The service will return the temp directory path.
 *
 * @path		/path/temp
 * @verb		get
 * @response	{String}	The temp directory path.
 */
router.get(
	'/path/temp',
	(request, response) => { response.send( fs.getTempPath() ); },
	'tempPath'
)
	.response(
		[ 'application/text' ],
		"Temp path."
	)
	.summary(
		"Returns temp path"
	)
	.description(dd`
  Returns the temp path.
`);


/**
 * Test get temp file
 *
 * The service will return the temp file path.
 *
 * @path		/path/temp
 * @verb		get
 * @response	{String}	The temp file path.
 */
router.get(
	'/path/temp/file',
	(request, response) => {
		response.send( fs.getTempFile( fs.getTempPath(), false ) );
	},
	'tempPath'
)
	.response(
		[ 'application/text' ],
		"Temp path."
	)
	.summary(
		"Returns temp path"
	)
	.description(dd`
  Returns the temp path.
`);


/**
 * Test get authorisation data
 *
 * The service will return the authorisation data.
 *
 * @path		/auth/file
 * @verb		get
 * @response	{Object}	The authorisation data.
 */
router.get(
	'/auth/file',
	(request, response) => {
		try
		{
			const auth = Utils.auth.data();
			response.send( auth );
		}
		catch( error )
		{
			response.throw( 500, error );
		}
	},
	'authFile'
)
	.response(
		[ 'application/json' ],
		"Authorisation data."
	)
	.summary(
		"Returns authorisation data"
	)
	.description(dd`
  Returns the authorisation data.
`);


/**
 * Encode object
 *
 * The service will encode the object and return the token.
 *
 * The service expects two parameters in the body:
 * 	- key	{String}:	The encoding key.
 * 	- data	{Object}:	The data to encode.
 *
 * @path		/encode
 * @verb		post
 * @request		{Object}	{ key : <key>, data : <data to encode> }.
 * @response	{String}	The encoded token.
 */
router.post(
	'/encode',
	(request, response) => {

		//
		// Get parameters.
		//
		const key = request.body.key;
		const data = request.body.data;

		//
		// Encode.
		//
		try
		{
			response.send({
				token : Utils.auth.encode( key, data )
			});
		}
		catch( error )
		{
			response.throw( 500, error );
		}
	},
	'encode'
)
	.body(
		[ 'application/json' ],
		{
			key  : Joi.string().required,
			data : Joi.object().required()
		},
		"Request contents."
	)
	.response(
		[ 'application/json' ],
		"The token."
	)
	.summary(
		"Encode object"
	)
	.description(dd`
  Encodes the provided object and returns the token.
`);


/**
 * Decode object
 *
 * The service will decode the provided token and return the object.
 *
 * The service expects the path parameter to be the token
 * and the body to contain the key as "key".
 *
 * The service will return the object.
 *
 * @path		/decode
 * @verb		post
 * @request		{Object}	{ key : <key> }.
 * @response	{String}	The encoded token.
 */
router.post(
	'/decode/:token',
	(request, response) => {

		//
		// Get parameters.
		//
		const key = request.body.key;
		const token = request.pathParams.token;

		//
		// Decode.
		//
		try
		{
			response.send( Utils.auth.decode( key, token ) );
		}
		catch( error )
		{
			response.throw( 400, error );
		}
	},
	'decode'
)
	.pathParam(
		'token',
		Joi.string().required(),
		'Path parameter.'
	)
	.body(
		[ 'application/json' ],
		Joi.object({
			key  : Joi.string().required()
		}).required(),
		"Request contents."
	)
	.response(
		[ 'application/json' ],
		"The token."
	)
	.summary(
		"Encode object"
	)
	.description(dd`
  Decodes the provided token and returns the object.
`);


/**
 * Update collection indexes
 *
 * The service will create or update all collection indexes.
 *
 * @path		/index
 * @verb		get
 * @response	{Object}	The list of created indexes.
 */
router.get(
	'/index',
	(request, response) => {
		try
		{
			response.send({
				indexed : Application.init.collections.index()
			});
		}
		catch( error )
		{
			response.throw( 500, error );
		}
	},
	'index'
)
	.response(
		200,
		Joi.object({
			indexed : Joi.array().required()
		}).required(),
		'The processed collections.'
	)
	.summary(
		"Indexes all collections"
	)
	.description(dd`
  Will index all collections.
`);

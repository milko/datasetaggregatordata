'use strict';

/**
 * User services
 *
 * This path is used to handle user services.
 */

//
// Frameworks.
//
const dd = require('dedent');							// For multiline text.
const Joi = require('joi');								// Validation framework.
const createRouter = require('@arangodb/foxx/router');	// Router class.

//
// Application.
//
const User = require( '../utils/User' );				// Users.

//
// Models.
//
const SchemaUser = require( '../models/user' );			// User schema.
const SchemaLogin = require( '../models/login' );		// Login schema.
const SchemaAdmin = require( '../models/admin' );		// Admin init schema.

//
// Instantiate router.
//
const router = createRouter();
module.exports = router;


//
// Set router tags.
//
router.tag( 'user' );


/**
 * Current user
 *
 * The service will return the current user record, if there is no current
 * user, the service will return the 'username' property set to null.
 *
 * @path		/whoami
 * @verb		get
 * @response	{Object}	{ user : <current user record> }.
 */
router.get(

	//
	// Path.
	//
	'/whoami',

	//
	// Handler.
	//
	User.handlers.whoami,

	//
	// Name.
	//
	'whoami'
)
	.response(
		200,
		SchemaUser,
		'The user profile, or a null "username" property.'
	)
	.summary(
		"Get current user"
	)
	.description(dd`
  Return the current user.
`);


/**
 * Login
 *
 * The service will login a user.
 *
 * The service expects the following parameters in the body:
 * 	- username:	The user code.
 * 	- password:	The user password.
 *
 * The service will login the user, set the user _id in the session, ser the
 * user record in the request and return the user record; if the user cannot
 * be authenticated, the service will raise an exception.
 *
 *
 * @path		/signin/sysadm/:token
 * @verb		post
 * @request		{Object}	Authentication parameters from body.
 * @response	{Object}	The current user record.
 */
router.post(

	//
	// Path.
	//
	'/login',

	//
	// Handler.
	//
	User.handlers.login,

	//
	// Name.
	//
	'login'
)
	.body(
		SchemaLogin,
		'User credentials.'
	)
	.response(
		200,
		SchemaUser,
		'The user record.'
	)
	.response(
		404,
		'User not found.'
	)
	.response(
		403,
		'Invalid password.'
	)
	.summary(
		"Login user"
	)
	.description(dd`
  Login user and return record.
`);


/**
 * Logout
 *
 * The service will logout the current user and return the former user record;
 * if there was no former user, the service will return a null 'username' property.
 *
 * @path		/logout
 * @verb		get
 * @response	{Object}	Former user record.
 */
router.get(

	//
	// Path.
	//
	'/logout',

	//
	// Handler.
	//
	User.handlers.logout,

	//
	// Name.
	//
	'logout'
)
	.response(
		200,
		SchemaUser,
		'The former user record.'
	)
	.summary(
		"Logout current user"
	)
	.description(dd`
  Logout and return former current user.
`);


/**
 * Create system administrator
 *
 * The service will create the system administrator user.
 *
 * The service expects a path parameter that represents the authentication
 * token, this parameter will be named "token".
 *
 * The service expects the administrator's user data to be provided in the
 * body as follows:
 * 	- name:		The name of the user.
 * 	- pass:		The user password.
 * 	- email:	The user's e-mail address.
 * 	- language:	The user's preferred language code.
 *
 * The service will perform the following assertions:
 * 	- The users collection must be empty.
 * 	- The path parameter token must match the object stored in the auth.json
 * 	  file in the data directory.
 *
 * The service will return the newly created administrator record.
 *
 * @path		/signin/sysadm/:token
 * @verb		post
 * @request		{Object}	Authentication parameters and administrator user.
 * @response	{Object}	The newly created user.
 */
router.post(

	//
	// Path.
	//
	'/signin/admin/:token',

	//
	// Middleware.
	//
	User.middleware.assert.noUsers,			// Ensure users collection is empty.
	User.middleware.assert.token.admin,		// Match token with authorisation file.

	//
	// Handler.
	//
	User.handlers.signin.admin,

	//
	// Name.
	//
	'signinAdmin'
)
	.pathParam(
		'token',
		Joi.string().required(),
		'Path parameter.'
	)
	.body(
		SchemaAdmin,
		'User credentials.'
	)
	.response(
		201,
		SchemaUser,
		'The created system administrator.'
	)
	.summary(
		"Create system administrator"
	)
	.description(dd`
  Create system administrator user.
`);

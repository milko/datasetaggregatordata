'use strict';

/**
 * Test services
 *
 * This path is used to test services.
 */

//
// Import frameworks.
//
const dd = require('dedent');							// For multiline text.
const fs = require('fs');								// File system utilities.
const db = require('@arangodb').db;						// Database object.
const Joi = require('joi');								// Validation framework.
const aql = require('@arangodb').aql;					// AQL queries.
const crypto = require('@arangodb/crypto');				// Cryptographic functions.
const httpError = require('http-errors');				// HTTP errors.
const traversal = require("@arangodb/graph/traversal");	// Graph traversals.
const status = require('statuses');						// Don't know what it is.
const errors = require('@arangodb').errors;				// ArangoDB errors.
const createAuth = require('@arangodb/foxx/auth');		// Authentication framework.
const createRouter = require('@arangodb/foxx/router');	// Router class.
const jwtStorage = require('@arangodb/foxx/sessions/storages/jwt');

//
// Instantiate objects.
//
const K = require( '../utils/Constant' );
const Utils = require( '../utils/Utils' );
const MyError = require( '../utils/Error' );
const Schema = require( '../utils/Schema' );
const Validator = require( '../utils/Validator' );
const Collection = require( '../utils/Collection' );
const Dictionary = require( '../utils/Dictionary' );
const Application = require( '../utils/Application' );

//
// Error constants.
//
const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;
const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

//
// Instantiate router.
//
const auth = createAuth();
const router = createRouter();
module.exports = router;


//
// Set router tags.
//
router.tag( 'test' );


/**
 * Test error
 * The service will test throwing a custom error.
 *
 * @path		/error
 * @verb		get
 * @response	{array}	File lines.
 */
router.get(
	'/error',
	(request, response) =>
	{
		const error = new MyError(
			'EmptyCollection',
			K.error.MissingCollection,
			request.application.language,
			'schema'
		);

		// response.send( error );
		response.throw( 400, error );
	},
	'error'
)
	.response(
		[ 'application/json' ],
		"Should never get here."
	)
	.summary(
		"Throw an error"
	)
	.description(dd`
  Throws a custom error.
`);


/**
 * Init/teardown collections
 *
 * The service will initialise or teardown collections according to the
 * provided path parameters:
 *
 * 	- op:			Type of operation:
 * 	  - init:		Create/update collection.
 * 	  - tear:		Drop collection.
 * 	  	other:		Will throw a bad request error.
 *
 * 	- type:			Type of collection:
 *   	- document:	Document collections.
 *   	- edge:		Edge collections.
 * 	  	other:		Will throw a bad request error.
 *
 * @path		/collections/:op/:type
 * @verb		post
 * @response	{Object}	Function result.
 */
router.post(
	'/collections/:op/:type',
	(request, response) =>
	{
		//
		// Init local storage.
		//
		let operation = null;

		//
		// Parse operation type.
		//
		switch( request.pathParams.op )
		{
			case 'init':
				operation = Application.init;
				break;

			case 'tear':
				operation = Application.tear;
				break;

			default:
				response.throw(
					400,
					"Invalid operation parameter, expecting 'init' or 'tear'"
				);																// !@! ==>
		}

		try
		{
			//
			// Parse collection type.
			//
			switch( request.pathParams.type )
			{
				case 'index':
					if( request.pathParams.op === 'init' )
						response.send({
							collections : operation.collections.index()
						});															// ==>
					else
						response.throw(
							400,
							"Invalid operation parameter, expecting 'init'."
						);														// !@! ==>
					break;

				case 'document':
					response.send({
						collections : operation.collections.document()
					});																// ==>
					break;

				case 'edge':
					response.send({
						collections : operation.collections.edge()
					});																// ==>
					break;

				default:
					response.throw(
						400,
						"Invalid collection parameter, expecting 'document' or 'edge'."
					);															// !@! ==>
					break;
			}
		}
		catch( error )
		{
			response.throw( 500, error );										// !@! ==>
		}
	},
	'collections'
)
	.pathParam(
		'op',
		Joi.string().required(),
		'Operation type.'
	)
	.pathParam(
		'type',
		Joi.string().required(),
		'Collection type.'
	)
	.response(
		[ 'application/json' ],
		"The list of collection records."
	)
	.summary(
		"Get collections info"
	)
	.description(dd`
  Returns the list of collection records according to type (document/edge).
`);


/**
 * Test readLinesByCount()
 *
 * The service will test reading files in buffers.
 *
 * @path		/readLinesByCount
 * @verb		get
 * @response	{array}	File lines.
 */
router.get(
	'/readLinesByCount',
	(request, response) =>
	{
		const file = module.context.basePath
			+ fs.pathSeparator + 'data'
			+ fs.pathSeparator + 'test.json';
		const JsonLReader = require( '../utils/JsonLReader' );
		const reader = new JsonLReader( file );

		let lines = [];
		let current = reader.readLinesByCount();
		while( current !== null ) {
			let size = 0;
			current.map( line => size += line.length );
			lines.push({
				count : current.length,
				size : size
			});
			current = reader.readLinesByCount();
		}

		response.send({
			lines : lines
		});
	},
	'readLinesByCount'
)
	.response(
		[ 'application/json' ],
		"The file contents."
	)
	.summary(
		"Read a file with Buffer"
	)
	.description(dd`
  Returns file contents line by line.
`);


/**
 * Test readLinesBySize()
 *
 * The service will test reading files in buffers.
 *
 * @path		/readLinesBySize
 * @verb		get
 * @response	{array}	File lines.
 */
router.get(
	'/readLinesBySize',
	(request, response) =>
	{
		const file = module.context.basePath
			+ fs.pathSeparator + 'data'
			+ fs.pathSeparator + 'test.json';
		const JsonLReader = require( '../utils/JsonLReader' );
		const reader = new JsonLReader( file );

		let lines = [];
		let current = reader.readLinesBySize( 8192 );
		while( current !== null ) {
			let size = 0;
			current.map( line => size += line.length );
			lines.push({
				count : current.length,
				size : size
			});
			current = reader.readLinesBySize( 8192 );
		}

		response.send({
			lines : lines
		});
	},
	'readLinesBySize'
)
	.response(
		[ 'application/json' ],
		"The file contents."
	)
	.summary(
		"Read a file with Buffer"
	)
	.description(dd`
  Returns file contents line by line.
`);


/**
 * Test unzip file
 *
 * The service will test unzipping a file in the temporary directory.
 *
 * @path		/unzip
 * @verb		get
 * @response	{array}	File lines.
 */
router.get(
	'/unzip',
	(request, response) =>
	{
		const path = module.context.basePath + fs.pathSeparator + 'data';
		const file = path + fs.pathSeparator + 'descriptors.json.zip';
		const unzipped = path + fs.pathSeparator + 'temp';

		try
		{
			fs.unzipFile(file, path, null, true);
		}
		catch( error )
		{
			response.throw( error );
		}

		response.send( unzipped );
	},
	'unzip'
)
	.response(
		[ 'application/text' ],
		"The unzipped file's path."
	)
	.summary(
		"Unzip a file in the temp directory"
	)
	.description(dd`
  Unzips a file in the temp directory and returns its path.
`);


/**
 * Test import file
 *
 * The service will test importing a file into a collection.
 *
 * @path		/import/:collection
 * @verb		get
 * @response	{array}	File lines.
 */
router.get(
	'/import/:collection',
	(request, response) =>
	{
		const collection = request.pathParams.collection;
		const result = Utils.file.collection.import( collection );
		result.throwError( request, response );

		response.send( result );
	},
	'importCollection'
)
	.pathParam(
		'collection',
		Joi.string().required(),
		'Collection name.'
	)
	.response(
		[ 'application/json' ],
		"The operation results."
	)
	.summary(
		"import data into a collection"
	)
	.description(dd`
  Imports data into a collection, if empty.
`);


/**
 * Test getDocumentByFormat
 *
 * The service will test Dictionary.getDocumentByFormat.
 *
 * @path		/getDocumentByFormat
 * @verb		post
 * @response	{array}	File lines.
 */
router.post(
	'/getDocumentByFormat',
	(request, response) =>
	{
		try
		{
			const reference = request.body.reference;
			const collection = request.body.collection;
			const input  = request.body.input;
			const output  = request.body.output;
			const language  = request.body.language;
			const dictionary  = request.body.dictionary;

			const data = Dictionary.getDocumentByFormat(
				request, reference, collection, input, output, language, dictionary
			);

			response.send({ result : data });
		}
		catch( error )
		{
			response.throw( 500, error );
		}
	},
	'getDocumentByFormat'
)
	.body(
		Joi.object({
			reference	: Joi.any().required(),
			collection	: Joi.string().required(),
			input		: Joi.string().required(),
			output		: Joi.string().required(),
			language	: Joi.any(),
			dictionary	: Joi.any()
		}),
		'Document reference, collection, input and output formats, language and dictionary flag.'
	)
	.response(
		200,
		Joi.object({
			result : Joi.any()
		}),
		"The result of the operation."
	)
	.summary(
		"Get enumeration list of keys by variable name"
	)
	.description(dd`
  Returns the list of enumeration keys corresponding 
  to the variable name provided in the path.
`);


/**
 * Test checkEnumeration
 *
 * The service will test Dictionary.checkEnumeration.
 *
 * @path		/import/:collection
 * @verb		post
 * @response	{array}	File lines.
 */
router.post(
	'/checkEnumeration',
	(request, response) =>
	{
		const stamp = Date.now();
		try
		{
			const reference = request.body.reference;
			const branches = request.body.branches;

			const data = Dictionary.checkEnumeration(
				request,
				reference,
				branches
			);

			response.send({ result : data, time : Date.now() - stamp });
		}
		catch( error )
		{
			response.throw( 500, error );
		}
	},
	'checkEnumeration'
)
	.body(
		Joi.object({
			reference	: Joi.string().required(),
			branches	: Joi.array().required()
		}),
		'Enumeration _id and branches list.'
	)
	.response(
		200,
		Joi.object({
			result : Joi.any()
		}),
		"The result of the operation."
	)
	.summary(
		"Check if enumeration exists in optional branches"
	)
	.description(dd`
  Returns true if the reference is a term or an enumeration in the provided branches.
`);


/**
 * Test traverse graph
 *
 * The service will test traversing the graph.
 *
 * @path		/traverse
 * @verb		get
 * @response	{array}	File lines.
 */
router.get(
	'/traverse',
	(request, response) =>
	{
		const result = { list : [] };
		const config = {
			custom: {
				branch: 'terms/:enum:collection',
				predicates: [
					'terms/:predicate:enum-of',
					'terms/:predicate:category-of'
				]
			},
			datasource: traversal.collectionDatasourceFactory( 'schemas' ),
			expander : traversal.outboundExpander,
			strategy: "depthfirst",
			order: "preorder-expander",
			filter: traversal.visitAllFilter,
			expandFilter: (config, vertex, edge, path) => {
				if( config.custom.predicates.includes( edge.predicate )
					&& (edge.branches.includes( config.custom.branch ) ) )
					return true;
				return false;
			},
			visitor: (config, result, vertex, path, edge) => {
				result.list.push({ vertex: vertex._id, edge: edge});
			}
		};

		const startVertex = db._document("terms/:collection:annexes");
		const traverser = new traversal.Traverser(config);
		traverser.traverse(result, startVertex);

		response.send( result );
	},
	'traverse'
)
	.response(
		[ 'application/json' ],
		"The operation results."
	)
	.summary(
		"Traverse graph"
	)
	.description(dd`
  Test graph traversals.
`);


/**
 * Test getEnumList
 *
 * The service will test Dictionary.getDocumentByFormat.
 *
 * @path		/import/:collection
 * @verb		post
 * @response	{array}	File lines.
 */
router.post(
	'/getEnumList',
	(request, response) =>
	{
		try
		{
			const root = request.body.root;
			const branch = ( request.body.hasOwnProperty( 'branch' ) )
				? request.body.branch
				: null;
			const input  = request.body.input;
			const output  = request.body.output;
			const minDepth  = ( request.body.hasOwnProperty( 'minDepth' ) )
				? request.body.minDepth
				: null;
			const maxDepth  = ( request.body.hasOwnProperty( 'maxDepth' ) )
				? request.body.maxDepth
				: null;
			const includeRoot  = request.body.includeRoot;
			const restrictChoices  = request.body.restrictChoices;
			const restrictLanguage  = request.body.restrictLanguage;

			const list = Schema.getEnumList(
				request,
				root,
				branch,
				input,
				output,
				minDepth,
				maxDepth,
				includeRoot,
				restrictChoices,
				restrictLanguage
			);

			response.send({ result : list });
		}
		catch( error )
		{
			response.throw( 500, error );
		}
	},
	'getEnumList'
)
	.body(
		Joi.object({
			root : Joi.any().required(),
			branch : Joi.any(),
			input : Joi.string().required(),
			output : Joi.string().required(),
			minDepth : Joi.any().default(null),
			maxDepth : Joi.any().default(null),
			includeRoot : Joi.boolean().default(true),
			restrictChoices : Joi.boolean().default(false),
			restrictLanguage : Joi.boolean().default(false)
		}),
		'Root, branch, input and output formats, minimum and maximum depth and options.'
	)
	.response(
		200,
		Joi.object({
			result : Joi.any()
		}),
		"The result of the operation."
	)
	.summary(
		"Get enumeration list of elements"
	)
	.description(dd`
  Returns the list of enumeration elements
  corresponding to the variable name provided
  in the path.
`);


/**
 * Test getEnumPath
 *
 * The service will test Dictionary.getDocumentByFormat.
 *
 * @path		/import/:collection
 * @verb		post
 * @response	{array}	File lines.
 */
router.post(
	'/getEnumPath',
	(request, response) =>
	{
		try
		{
			const branch = request.body.branch;
			const leaf = request.body.leaf;
			const root = ( request.body.hasOwnProperty( 'root' ) )
				? request.body.root
				: null;
			const input  = request.body.input;
			const output  = request.body.output;
			const includeRoot  = request.body.includeRoot;
			const restrictChoices  = request.body.restrictChoices;
			const restrictLanguage  = request.body.restrictLanguage;

			const list = Schema.getEnumPath(
				request,
				branch,
				leaf,
				root,
				input,
				output,
				includeRoot,
				restrictChoices,
				restrictLanguage
			);

			response.send({ result : list });
		}
		catch( error )
		{
			response.throw( 500, error );
		}
	},
	'getEnumPath'
)
	.body(
		Joi.object({
			branch : Joi.any().required(),
			leaf : Joi.any().required(),
			root : Joi.any(),
			input : Joi.string().required(),
			output : Joi.string().required(),
			includeRoot : Joi.boolean().default(true),
			restrictChoices : Joi.boolean().default(false),
			restrictLanguage : Joi.boolean().default(false)
		}),
		'Leaf, root, branch, input and output formats, minimum and maximum depth and options.'
	)
	.response(
		200,
		Joi.object({
			result : Joi.any()
		}),
		"The result of the operation."
	)
	.summary(
		"Get enumeration list of keys by variable name"
	)
	.description(dd`
  Returns the list of enumeration keys corresponding 
  to the variable name provided in the path.
`);


/**
 * Test validator constructor
 *
 * The service will test the validator constructor.
 *
 * @path		/validator/construct
 * @verb		get
 * @response	Stuff.
 */
router.get(
	'/validator/construct',
	(request, response) =>
	{
		const validator = new Validator( request );


		response.send( validator );
	},
	'validator_construct'
)
	.response(
		[ 'application/json' ],
		"The validator contents after construction."
	)
	.summary(
		"Test validator constructor"
	)
	.description(dd`
  Test constructor of validator object.
`);


/**
 * Test validator getValidator() method
 *
 * The service will test the validator getValidator() method.
 *
 * @path		/validator/method
 * @verb		get
 * @response	Stuff.
 */
router.get(
	'/validator/getValidator',
	(request, response) =>
	{
		const validator = new Validator( request );
		const result = validator.getValidator(request, 'label' );

		response.send( result );
	},
	'validator_getValidator'
)
	.response(
		[ 'application/json' ],
		"The getValidator() contents."
	)
	.summary(
		"Test validator getValidator() method"
	)
	.description(dd`
  Test getValidator() method of validator object.
`);

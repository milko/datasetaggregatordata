'use strict';
const dd = require('dedent');
const joi = require('joi');
const httpError = require('http-errors');
const status = require('statuses');
const errors = require('@arangodb').errors;
const createRouter = require('@arangodb/foxx/router');
const Setting = require('../models/setting');

const settings = module.context.collection('settings');
const keySchema = joi.string().required()
.description('The key of the setting');

const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;
const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

const router = createRouter();
module.exports = router;


router.tag('setting');


router.get(function (req, res) {
  res.send(settings.all());
}, 'list')
.response([Setting], 'A list of settings.')
.summary('List all settings')
.description(dd`
  Retrieves a list of all settings.
`);


router.post(function (req, res) {
  const setting = req.body;
  let meta;
  try {
    meta = settings.save(setting);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_DUPLICATE) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(setting, meta);
  res.status(201);
  res.set('location', req.makeAbsolute(
    req.reverse('detail', {key: setting._key})
  ));
  res.send(setting);
}, 'create')
.body(Setting, 'The setting to create.')
.response(201, Setting, 'The created setting.')
.error(HTTP_CONFLICT, 'The setting already exists.')
.summary('Create a new setting')
.description(dd`
  Creates a new setting from the request body and
  returns the saved document.
`);


router.get(':key', function (req, res) {
  const key = req.pathParams.key;
  let setting
  try {
    setting = settings.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
  res.send(setting);
}, 'detail')
.pathParam('key', keySchema)
.response(Setting, 'The setting.')
.summary('Fetch a setting')
.description(dd`
  Retrieves a setting by its key.
`);


router.put(':key', function (req, res) {
  const key = req.pathParams.key;
  const setting = req.body;
  let meta;
  try {
    meta = settings.replace(key, setting);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(setting, meta);
  res.send(setting);
}, 'replace')
.pathParam('key', keySchema)
.body(Setting, 'The data to replace the setting with.')
.response(Setting, 'The new setting.')
.summary('Replace a setting')
.description(dd`
  Replaces an existing setting with the request body and
  returns the new document.
`);


router.patch(':key', function (req, res) {
  const key = req.pathParams.key;
  const patchData = req.body;
  let setting;
  try {
    settings.update(key, patchData);
    setting = settings.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  res.send(setting);
}, 'update')
.pathParam('key', keySchema)
.body(joi.object().description('The data to update the setting with.'))
.response(Setting, 'The updated setting.')
.summary('Update a setting')
.description(dd`
  Patches a setting with the request body and
  returns the updated document.
`);


router.delete(':key', function (req, res) {
  const key = req.pathParams.key;
  try {
    settings.remove(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
}, 'delete')
.pathParam('key', keySchema)
.response(null)
.summary('Remove a setting')
.description(dd`
  Deletes a setting from the database.
`);

'use strict';

/**
 * Event constants
 */
module.exports = {
	login			: 'LOGIN'
};
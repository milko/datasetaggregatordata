'use strict';
const dd = require('dedent');
const joi = require('joi');
const httpError = require('http-errors');
const status = require('statuses');
const errors = require('@arangodb').errors;
const createRouter = require('@arangodb/foxx/router');
const E = require('../models/e');

const eItems = module.context.collection('e');
const keySchema = joi.string().required()
.description('The key of the e');

const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;
const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

const router = createRouter();
module.exports = router;


router.tag('e');


const NewE = Object.assign({}, E, {
  schema: Object.assign({}, E.schema, {
    _from: joi.string(),
    _to: joi.string()
  })
});


router.get(function (req, res) {
  res.send(eItems.all());
}, 'list')
.response([E], 'A list of eItems.')
.summary('List all eItems')
.description(dd`
  Retrieves a list of all eItems.
`);


router.post(function (req, res) {
  const e = req.body;
  let meta;
  try {
    meta = eItems.save(e._from, e._to, e);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_DUPLICATE) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(e, meta);
  res.status(201);
  res.set('location', req.makeAbsolute(
    req.reverse('detail', {key: e._key})
  ));
  res.send(e);
}, 'create')
.body(NewE, 'The e to create.')
.response(201, E, 'The created e.')
.error(HTTP_CONFLICT, 'The e already exists.')
.summary('Create a new e')
.description(dd`
  Creates a new e from the request body and
  returns the saved document.
`);


router.get(':key', function (req, res) {
  const key = req.pathParams.key;
  let e
  try {
    e = eItems.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
  res.send(e);
}, 'detail')
.pathParam('key', keySchema)
.response(E, 'The e.')
.summary('Fetch a e')
.description(dd`
  Retrieves a e by its key.
`);


router.put(':key', function (req, res) {
  const key = req.pathParams.key;
  const e = req.body;
  let meta;
  try {
    meta = eItems.replace(key, e);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(e, meta);
  res.send(e);
}, 'replace')
.pathParam('key', keySchema)
.body(E, 'The data to replace the e with.')
.response(E, 'The new e.')
.summary('Replace a e')
.description(dd`
  Replaces an existing e with the request body and
  returns the new document.
`);


router.patch(':key', function (req, res) {
  const key = req.pathParams.key;
  const patchData = req.body;
  let e;
  try {
    eItems.update(key, patchData);
    e = eItems.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  res.send(e);
}, 'update')
.pathParam('key', keySchema)
.body(joi.object().description('The data to update the e with.'))
.response(E, 'The updated e.')
.summary('Update a e')
.description(dd`
  Patches a e with the request body and
  returns the updated document.
`);


router.delete(':key', function (req, res) {
  const key = req.pathParams.key;
  try {
    eItems.remove(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
}, 'delete')
.pathParam('key', keySchema)
.response(null)
.summary('Remove a e')
.description(dd`
  Deletes a e from the database.
`);

'use strict';
const dd = require('dedent');
const joi = require('joi');
const httpError = require('http-errors');
const status = require('statuses');
const errors = require('@arangodb').errors;
const createRouter = require('@arangodb/foxx/router');
const V = require('../models/v');

const vItems = module.context.collection('v');
const keySchema = joi.string().required()
.description('The key of the v');

const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;
const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

const router = createRouter();
module.exports = router;


router.tag('v');


router.get(function (req, res) {
  res.send(vItems.all());
}, 'list')
.response([V], 'A list of vItems.')
.summary('List all vItems')
.description(dd`
  Retrieves a list of all vItems.
`);


router.post(function (req, res) {
  const v = req.body;
  let meta;
  try {
    meta = vItems.save(v);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_DUPLICATE) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(v, meta);
  res.status(201);
  res.set('location', req.makeAbsolute(
    req.reverse('detail', {key: v._key})
  ));
  res.send(v);
}, 'create')
.body(V, 'The v to create.')
.response(201, V, 'The created v.')
.error(HTTP_CONFLICT, 'The v already exists.')
.summary('Create a new v')
.description(dd`
  Creates a new v from the request body and
  returns the saved document.
`);


router.get(':key', function (req, res) {
  const key = req.pathParams.key;
  let v
  try {
    v = vItems.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
  res.send(v);
}, 'detail')
.pathParam('key', keySchema)
.response(V, 'The v.')
.summary('Fetch a v')
.description(dd`
  Retrieves a v by its key.
`);


router.put(':key', function (req, res) {
  const key = req.pathParams.key;
  const v = req.body;
  let meta;
  try {
    meta = vItems.replace(key, v);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  Object.assign(v, meta);
  res.send(v);
}, 'replace')
.pathParam('key', keySchema)
.body(V, 'The data to replace the v with.')
.response(V, 'The new v.')
.summary('Replace a v')
.description(dd`
  Replaces an existing v with the request body and
  returns the new document.
`);


router.patch(':key', function (req, res) {
  const key = req.pathParams.key;
  const patchData = req.body;
  let v;
  try {
    vItems.update(key, patchData);
    v = vItems.document(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    if (e.isArangoError && e.errorNum === ARANGO_CONFLICT) {
      throw httpError(HTTP_CONFLICT, e.message);
    }
    throw e;
  }
  res.send(v);
}, 'update')
.pathParam('key', keySchema)
.body(joi.object().description('The data to update the v with.'))
.response(V, 'The updated v.')
.summary('Update a v')
.description(dd`
  Patches a v with the request body and
  returns the updated document.
`);


router.delete(':key', function (req, res) {
  const key = req.pathParams.key;
  try {
    vItems.remove(key);
  } catch (e) {
    if (e.isArangoError && e.errorNum === ARANGO_NOT_FOUND) {
      throw httpError(HTTP_NOT_FOUND, e.message);
    }
    throw e;
  }
}, 'delete')
.pathParam('key', keySchema)
.response(null)
.summary('Remove a v')
.description(dd`
  Deletes a v from the database.
`);

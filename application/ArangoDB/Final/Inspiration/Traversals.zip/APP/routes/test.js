'use strict';

const dd = require('dedent');
const db = require('@arangodb').db;
const joi = require('joi');
const httpError = require('http-errors');
const status = require('statuses');
const errors = require('@arangodb').errors;
const createRouter = require('@arangodb/foxx/router');
const V = require('../models/v');

const vItems = db._collection('v');
const keySchema = joi.string().required()
.description('The key of the v');

const ARANGO_NOT_FOUND = errors.ERROR_ARANGO_DOCUMENT_NOT_FOUND.code;
const ARANGO_DUPLICATE = errors.ERROR_ARANGO_UNIQUE_CONSTRAINT_VIOLATED.code;
const ARANGO_CONFLICT = errors.ERROR_ARANGO_CONFLICT.code;
const HTTP_NOT_FOUND = status('not found');
const HTTP_CONFLICT = status('conflict');

//
// Traversal stuff.
//
const traversal = require("@arangodb/graph/traversal");
const result = {
	visited: {
		vertices: [],
		paths: []
	}
};

const router = createRouter();
module.exports = router;


router.tag('test');


router.get(
	'/test0',
	function (req, res)
	{
		const config = {
			datasource: traversal.generalGraphDatasourceFactory("worldCountry"),
			strategy: "depthfirst",
// 			order: "preorder-expander",
			strategy: "depthfirst",
			filter: traversal.visitAllFilter,
			sort: function (l, r) { return l._key < r._key ? 1 : -1; },
			expander: traversal.inboundExpander,
// 			visitor: traversal.trackingVisitor,
// 			visitor: (config, result, vertex, path, connected) => {
// 				if( ! result.hasOwnProperty( 'leafs' ) )
// 					result.leafs = [];
// 				if( ! result.hasOwnProperty( 'path' ) )
// 					result.path = [];
// 				if (connected && connected.length === 0) {
// 					result.leafs.push( vertex );
// 				}
// 				if( path.edges.length || path.vertices.length )
// 					result.path.push( path );
// 			},
			maxDepth: 2
		};
		
		res.send({ type : config.datasource });
		
	}, 'pippo')
	.response([V], 'A list of vItems.')
	.summary('List all vItems')
	.description(dd`
	Retrieves a list of all vItems.
	`);


router.get(
	'/test1',
	function (req, res)
	{
		const config = {
			datasource: traversal.generalGraphDatasourceFactory("worldCountry"),
			strategy: "depthfirst",
// 			order: "preorder-expander",
			strategy: "depthfirst",
			filter: traversal.visitAllFilter,
			sort: function (l, r) { return l._key < r._key ? 1 : -1; },
			expander: traversal.inboundExpander,
// 			visitor: traversal.trackingVisitor,
// 			visitor: (config, result, vertex, path, connected) => {
// 				if( ! result.hasOwnProperty( 'leafs' ) )
// 					result.leafs = [];
// 				if( ! result.hasOwnProperty( 'path' ) )
// 					result.path = [];
// 				if (connected && connected.length === 0) {
// 					result.leafs.push( vertex );
// 				}
// 				if( path.edges.length || path.vertices.length )
// 					result.path.push( path );
// 			},
			maxDepth: 2
		};
		
		const startVertex = db._document("v/world");
		
		const traverser = new traversal.Traverser(config);
		traverser.traverse(result, startVertex);
		
		const out = result.visited.vertices.map( (vertex) => {
			return vertex.name + " (" + vertex.type + ")";
		});
		
// 		res.send({ result : out });
		res.send(result);
		
	}, 'list')
	.response([V], 'A list of vItems.')
	.summary('List all vItems')
	.description(dd`
	Retrieves a list of all vItems.
	`);


router.get(
	'/map',
	function (req, res)
	{
		const result = {
			vertices: [],
			edges: [],
			map: {
				terms: {},
				edges: {}
			},
			tree : null
		};
		const config = {
			datasource: traversal.generalGraphDatasourceFactory("worldCountry"),
			strategy: "depthfirst",
			filter: traversal.visitAllFilter,
			expander: traversal.inboundExpander,
			visitor: (config, result, vertex, path) => {
			
				result.map.terms[ vertex._id ] = result.vertices.length;
				result.vertices.push( vertex );
				
				if( path.edges.length ) {
					const edge = path.edges[ 0 ];
					result.map.edges[ edge._id ] = result.edges.length;
					result.edges.push( edge );
				}
			},
			maxDepth: 1
		};
		
		const startVertex = db._document("v/world");
		
		const traverser = new traversal.Traverser(config);
		traverser.traverse(result, startVertex);
		
		res.send(result);
		
	}, 'list')
	.response([V], 'A list of vItems.')
	.summary('List all vItems')
	.description(dd`
	Retrieves a list of all vItems.
	`);


router.get(
	'/tree',
	function (req, res)
	{
		const result = {
			vertices : {},
			tree : null,
			dir : {}
		};
		const config = {
			datasource: traversal.generalGraphDatasourceFactory("worldCountry"),
			strategy: "depthfirst",
			filter: traversal.visitAllFilter,
			sort: function (l, r) { return l.name < r.name ? 1 : -1; },
			expander: traversal.inboundExpander,
			visitor: (config, result, vertex, path) => {
				
				//
				// Add vertex.
				//
				result.vertices[ vertex._id ] = vertex;
				
				//
				// Handle root.
				//
				if( path.edges.length === 0 ) {
					result.tree = vertex;
					result.dir[ vertex._id ] = [ vertex._id ];
				}
				
				//
				// Handle children.
				//
				else
				{
					const fid = path.vertices[ path.vertices.length - 2 ]._id;
					const father = result.vertices[ fid ];
					
					//
					// Add children container.
					//
					if( ! father.hasOwnProperty( '_children' ) )
						father._children = [];
					
					//
					// Add child.
					//
					father._children.push( vertex );
					
					//
					// Add path.
					//
					result.dir[ vertex._id ] = [];
					for( const item of path.vertices )
						result.dir[ vertex._id ].push( item._id );
				}
				
			},
// 			maxDepth: 5
		};
		
		const startVertex = db._document("v/world");
		
		const traverser = new traversal.Traverser(config);
		traverser.traverse(result, startVertex);
		
		res.send({ map: result.dir, tree: result.tree });
		
	}, 'list')
	.response([V], 'A list of vItems.')
	.summary('List all vItems')
	.description(dd`
	Retrieves a list of all vItems.
	`);


router.get(
	'/bis',
	function (req, res)
	{
		const result = { root : null };
		const config = {
			datasource: traversal.generalGraphDatasourceFactory("worldCountry"),
			strategy: "depthfirst",
			filter: traversal.visitAllFilter,
			expander: traversal.inboundExpander,
			visitor: (config, result, vertex, path) => {
				
				//
				// Handle root.
				//
				if( path.edges.length === 0 ) {
					result.root = vertex;
				}
				
				//
				// Handle children.
				//
				else
				{
					//
					// Get parents.
					//
					const parent_v = path.vertices[ path.vertices.length - 2 ];
					const parent_e = path.edges[ path.edges.length - 1 ];
					
					//
					// Add children container.
					//
					if( ! parent_v.hasOwnProperty( '_children' ) )
						parent_v._children = [];
					
					//
					// Add child.
					//
					parent_v._children.push({ edge : parent_e, vertex : vertex });
				}
				
			},
// 			maxDepth: 5
		};
		
		const startVertex = db._document("v/world");
		
		const traverser = new traversal.Traverser(config);
		traverser.traverse(result, startVertex);
		
		res.send( result );
		
	}, 'list')
	.response([V], 'A list of vItems.')
	.summary('List all vItems')
	.description(dd`
	Retrieves a list of all vItems.
	`);


router.get(
	'/filter',
	function (req, res)
	{
		const result = { vertices : [] };
		const config = {
			datasource: traversal.collectionDatasourceFactory( 'e' ),
			strategy: "depthfirst",
			filter: (config, vertex, path) => {
				if( vertex.type === 'continent' )
					return "exclude";
				return undefined;
			},
// 			visitor: traversal.trackingVisitor,
			visitor: (config, result, vertex, path) => {
				
				//
				// Copy vertex.
				//
				result.vertices.push( vertex );
			},
			expander: traversal.inboundExpander
		};
		
		const startVertex = db._document("v/world");
		
		const traverser = new traversal.Traverser(config);
		traverser.traverse(result, startVertex);
		
		res.send(result);
		
	}, 'list')
	.response([V], 'A list of vItems.')
	.summary('List all vItems')
	.description(dd`
	Retrieves a list of all vItems.
	`);

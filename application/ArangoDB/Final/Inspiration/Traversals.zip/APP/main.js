'use strict';

module.context.use('/v', require('./routes/v'), 'v');
module.context.use('/e', require('./routes/e'), 'e');

module.context.use('/test', require('./routes/test'), 'test');

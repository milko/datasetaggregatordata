//
// Credentials authorisation.
//
'use strict';
const createAuth = require('@arangodb/foxx/auth');

module.exports = createAuth();

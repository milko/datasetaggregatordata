This repository goes along with the ArangoDB tutorial
[Foxx Fine-Grained Permissions](https://www.arangodb.com/foxx-fine-grained-permissions/).

Each step of the tutorial is represented by a separate commit, the beginning of each section is marked with a git tag.

Check the [commit history](https://github.com/arangodb-foxx/fine-grained-permissions/commits/master) to jump to a specific step.

Check the [tag list](https://github.com/arangodb-foxx/fine-grained-permissions/tags) to jump to a specific section.
